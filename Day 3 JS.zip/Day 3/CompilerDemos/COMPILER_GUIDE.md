# React 19 Compiler Demo & Instructions

This project demonstrates the powerful new React 19 Compiler and its automatic optimization features.

## 🚀 What is the React Compiler?

The React Compiler is a revolutionary new feature in React 19 that automatically optimizes your React components without requiring manual performance optimizations like `useMemo`, `useCallback`, or `memo` in most cases.

### Key Benefits:
- ✅ **Automatic Memoization**: Expensive calculations are automatically cached
- ✅ **Smart Re-renders**: Components only re-render when necessary
- ✅ **Stable References**: Function references are automatically stabilized
- ✅ **Zero Configuration**: Works out of the box with minimal setup
- ✅ **Better Performance**: Optimal performance without manual optimization

## 🛠️ Setup Instructions

### 1. Prerequisites
Make sure you have the React Compiler configured in your project:

**vite.config.js** should include:
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [
    react({
      babel: {
        plugins: [['babel-plugin-react-compiler']],
      },
    }),
  ],
})
```

**package.json** should include:
```json
{
  "dependencies": {
    "react": "^19.2.0",
    "react-dom": "^19.2.0"
  },
  "devDependencies": {
    "babel-plugin-react-compiler": "^19.1.0-rc.3"
  }
}
```

### 2. Running the Demo

1. **Install dependencies** (if not already done):
   ```bash
   npm install
   ```

2. **Start the development server**:
   ```bash
   npm run dev
   ```

3. **Open your browser** to `http://localhost:5173`

4. **Open Developer Console** to see the optimization logs!

## 📋 Demo Components Explained

### 1. Basic Compiler Demo
- Shows automatic optimization of expensive calculations
- Demonstrates how the compiler handles state updates
- Includes todo list functionality to show component optimization

### 2. Advanced Compiler Demo  
- Complex data filtering and sorting
- User management with dynamic state
- Statistical calculations automatically optimized
- Shows how compiler handles derived state

### 3. Performance Demo
- Heavy data processing (1000+ items)
- Real-time performance comparison
- Console logging to show optimization in action
- Force re-renders to test compiler efficiency

## 🧠 How the React Compiler Works

### Before React Compiler:
```javascript
// Manual optimization required
const expensiveValue = useMemo(() => {
  return heavyCalculation(data);
}, [data]);

const handleClick = useCallback(() => {
  doSomething();
}, []);

const MyComponent = memo(({ data }) => {
  // Component logic
});
```

### With React Compiler:
```javascript
// Automatic optimization - no manual work needed!  
const expensiveValue = heavyCalculation(data); // Automatically memoized
const handleClick = () => doSomething(); // Automatically stable
const MyComponent = ({ data }) => {
  // Component logic - automatically optimized
};
```

## 🔍 What to Look For

### 1. Console Logs
Watch the browser console while using the demos:
- Notice how expensive operations don't re-run unnecessarily
- See which components actually re-render
- Compare performance before/after state changes

### 2. Performance Indicators
- **Expensive calculations** only run when dependencies change
- **Child components** only re-render when their props change
- **Event handlers** remain stable across re-renders
- **Complex filtering/sorting** is automatically optimized

### 3. Interactive Features
- Try the counter and notice calculation optimization
- Filter the user list and see smart re-rendering
- Force re-renders in the performance demo
- Add/remove todo items to see component optimization

## 📊 Compiler Rules & Best Practices

### The Compiler Automatically Handles:
1. **Memoization** of expensive computations
2. **Stable references** for functions and objects
3. **Component re-render optimization**
4. **Prop drilling optimization**
5. **Conditional rendering optimization**

### When You Still Need Manual Optimization:
- External API calls (use React Query/SWR)
- Complex async operations
- Third-party library integrations
- Very specific edge cases

### Writing Compiler-Friendly Code:
- Use pure functions when possible
- Avoid mutating props or state directly
- Keep component logic straightforward
- Let the compiler do the heavy lifting!

## 🎯 Testing the Compiler

### 1. Open Browser DevTools
- Go to the Console tab
- Watch for optimization logs as you interact

### 2. Try These Interactions:
- **Basic Demo**: Increment counter, add todos, change name
- **Advanced Demo**: Search users, change sorting, toggle user status  
- **Performance Demo**: Filter data, force re-renders, regenerate data

### 3. Notice the Optimization:
- Expensive operations don't re-run unnecessarily
- Components only re-render when needed
- Console logs show which optimizations are happening

## 🚀 Next Steps

1. **Experiment**: Try breaking the optimization by forcing unnecessary re-renders
2. **Build**: Create your own components and see the compiler at work
3. **Profile**: Use React DevTools Profiler to see performance improvements
4. **Learn**: Read the official React 19 documentation for advanced features

## 💡 Pro Tips

- **Let the compiler work**: Don't over-optimize manually
- **Use ESLint rules**: Install React Compiler ESLint rules for best practices
- **Monitor performance**: Use React DevTools to verify optimizations
- **Start simple**: Begin with basic components and gradually add complexity
- **Trust the compiler**: It's smarter than manual optimization in most cases!

---

**Happy coding with React 19! 🎉**