import { useState } from 'react';

// Component showing performance comparison with and without compiler optimizations
const PerformanceDemo = () => {
  const [renderCount, setRenderCount] = useState(0);
  const [heavyData, setHeavyData] = useState(generateHeavyData());
  const [filter, setFilter] = useState('');

  function generateHeavyData() {
    console.log('🔥 Generating heavy data...');
    return Array.from({ length: 1000 }, (_, i) => ({
      id: i,
      name: `Item ${i}`,
      value: Math.random() * 1000,
      category: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
      timestamp: Date.now() + i
    }));
  }

  // Heavy computation that would benefit from compiler memoization
  const processData = () => {
    console.log('📊 Processing data...');
    return heavyData
      .filter(item => item.name.toLowerCase().includes(filter.toLowerCase()))
      .sort((a, b) => b.value - a.value)
      .slice(0, 50)
      .map(item => ({
        ...item,
        formatted: `${item.name}: ${item.value.toFixed(2)} (${item.category})`,
        processed: true
      }));
  };

  const processedData = processData();

  // Statistics calculation
  const stats = {
    total: heavyData.length,
    filtered: processedData.length,
    avgValue: processedData.reduce((sum, item) => sum + item.value, 0) / processedData.length || 0,
    categories: [...new Set(processedData.map(item => item.category))].length
  };

  const forceRerender = () => {
    setRenderCount(count => count + 1);
  };

  const regenerateData = () => {
    setHeavyData(generateHeavyData());
  };

  return (
    <div style={{ padding: '20px', maxWidth: '900px', margin: '0 auto' }}>
      <h1>⚡ Performance Demo - React Compiler</h1>
      
      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Performance Controls</h2>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '15px', flexWrap: 'wrap' }}>
          <button onClick={forceRerender} style={{ padding: '8px 16px' }}>
            Force Re-render ({renderCount})
          </button>
          <button onClick={regenerateData} style={{ padding: '8px 16px' }}>
            🔄 Regenerate Data
          </button>
          <input
            type="text"
            placeholder="Filter items..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{ padding: '8px', flex: '1', minWidth: '200px' }}
          />
        </div>
        
        <div style={{ fontSize: '14px', color: '#666' }}>
          💡 <strong>Watch the console:</strong> With React Compiler, expensive operations 
          are automatically memoized and won't re-run unnecessarily!
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
        <StatsPanel stats={stats} />
        <RenderInfo renderCount={renderCount} dataLength={heavyData.length} />
      </div>

      <div style={{ padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h3>Processed Data (Top 50 items)</h3>
        <DataList items={processedData} />
      </div>

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#fff3cd', borderRadius: '8px' }}>
        <h3>🧪 What's Happening:</h3>
        <ul>
          <li><strong>Data Processing:</strong> Heavy filtering/sorting automatically memoized</li>
          <li><strong>Statistics:</strong> Complex calculations cached until dependencies change</li>
          <li><strong>Child Components:</strong> Only re-render when their props actually change</li>
          <li><strong>Event Handlers:</strong> Automatically stable, preventing unnecessary re-renders</li>
          <li><strong>Performance:</strong> Optimal out of the box without manual optimization!</li>
        </ul>
      </div>
    </div>
  );
};

const StatsPanel = ({ stats }) => {
  console.log('📈 StatsPanel rendered');
  
  return (
    <div style={{ padding: '15px', border: '2px solid #4caf50', borderRadius: '8px' }}>
      <h3 style={{ margin: '0 0 15px 0', color: '#4caf50' }}>📊 Statistics</h3>
      <div style={{ display: 'grid', gap: '8px' }}>
        <StatRow label="Total Items" value={stats.total} />
        <StatRow label="Filtered Items" value={stats.filtered} />
        <StatRow label="Average Value" value={stats.avgValue.toFixed(2)} />
        <StatRow label="Categories" value={stats.categories} />
      </div>
    </div>
  );
};

const RenderInfo = ({ renderCount, dataLength }) => {
  console.log('🎯 RenderInfo rendered');
  
  return (
    <div style={{ padding: '15px', border: '2px solid #2196f3', borderRadius: '8px' }}>
      <h3 style={{ margin: '0 0 15px 0', color: '#2196f3' }}>🎯 Render Info</h3>
      <div style={{ display: 'grid', gap: '8px' }}>
        <StatRow label="Render Count" value={renderCount} />
        <StatRow label="Data Size" value={dataLength} />
        <StatRow label="Last Render" value={new Date().toLocaleTimeString()} />
        <div style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
          💡 Thanks to React Compiler, expensive operations are automatically optimized!
        </div>
      </div>
    </div>
  );
};

const StatRow = ({ label, value }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
    <span style={{ fontSize: '14px' }}>{label}:</span>
    <span style={{ fontWeight: 'bold' }}>{value}</span>
  </div>
);

const DataList = ({ items }) => {
  console.log('📋 DataList rendered');
  
  return (
    <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
      {items.map(item => (
        <DataItem key={item.id} item={item} />
      ))}
    </div>
  );
};

const DataItem = ({ item }) => {
  // This will only re-render when the specific item changes
  // console.log(`📦 DataItem ${item.id} rendered`);
  
  return (
    <div style={{
      padding: '10px',
      margin: '5px 0',
      backgroundColor: '#f8f9fa',
      borderRadius: '4px',
      borderLeft: `4px solid ${getCategoryColor(item.category)}`,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }}>
      <div>
        <div style={{ fontWeight: 'bold' }}>{item.name}</div>
        <div style={{ fontSize: '12px', color: '#666' }}>
          Category: {item.category} | Value: {item.value.toFixed(2)}
        </div>
      </div>
      <div style={{
        padding: '4px 8px',
        backgroundColor: getCategoryColor(item.category),
        color: 'white',
        borderRadius: '12px',
        fontSize: '12px'
      }}>
        {item.category}
      </div>
    </div>
  );
};

function getCategoryColor(category) {
  const colors = {
    'A': '#e74c3c',
    'B': '#3498db',
    'C': '#2ecc71',
    'D': '#f39c12'
  };
  return colors[category] || '#95a5a6';
}

export default PerformanceDemo;