import { useState, useMemo, useCallback, memo } from 'react';

// Component to demonstrate React Compiler optimizations
const CompilerDemo = () => {
  const [count, setCount] = useState(0);
  const [name, setName] = useState('React 19');
  const [items, setItems] = useState([
    { id: 1, text: 'Learn React 19', completed: false },
    { id: 2, text: 'Try React Compiler', completed: false },
    { id: 3, text: 'Build awesome apps', completed: false }
  ]);

  // Before React Compiler: You'd need useMemo to optimize this
  // With React Compiler: Automatically optimized!
  const expensiveCalculation = () => {
    console.log('🔥 Expensive calculation running...');
    let result = 0;
    for (let i = 0; i < count * 1000; i++) {
      result += Math.random();
    }
    return result.toFixed(2);
  };

  // Before React Compiler: You'd need useCallback to optimize this
  // With React Compiler: Automatically optimized!
  const handleAddItem = (text) => {
    setItems(prev => [...prev, {
      id: Date.now(),
      text,
      completed: false
    }]);
  };

  const handleToggleItem = (id) => {
    setItems(prev => prev.map(item =>
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const completedCount = items.filter(item => item.completed).length;

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h1>🚀 React 19 Compiler Demo</h1>
      
      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Counter & Expensive Calculation</h2>
        <p>Count: {count}</p>
        <p>Expensive Result: {expensiveCalculation()}</p>
        <button onClick={() => setCount(c => c + 1)}>Increment Count</button>
        <button onClick={() => setCount(0)} style={{ marginLeft: '10px' }}>Reset</button>
      </div>

      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Dynamic Content</h2>
        <input 
          value={name} 
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
          style={{ padding: '8px', marginRight: '10px' }}
        />
        <p>Hello, {name}! 👋</p>
      </div>

      <div style={{ padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Todo List ({completedCount}/{items.length} completed)</h2>
        <TodoList 
          items={items} 
          onToggle={handleToggleItem}
          onAdd={handleAddItem}
        />
      </div>

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
        <h3>🧠 React Compiler Benefits:</h3>
        <ul>
          <li>✅ Automatic memoization of expensive calculations</li>
          <li>✅ Auto-optimized callback functions</li>
          <li>✅ Smart re-render prevention</li>
          <li>✅ No need for manual useMemo/useCallback in most cases</li>
          <li>✅ Better performance out of the box</li>
        </ul>
      </div>
    </div>
  );
};

// Child component that would benefit from React Compiler optimizations
const TodoList = memo(({ items, onToggle, onAdd }) => {
  const [newItem, setNewItem] = useState('');

  console.log('📝 TodoList rendered');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newItem.trim()) {
      onAdd(newItem.trim());
      setNewItem('');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit} style={{ marginBottom: '15px' }}>
        <input
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          placeholder="Add new task..."
          style={{ padding: '8px', marginRight: '10px', width: '200px' }}
        />
        <button type="submit">Add Task</button>
      </form>
      
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {items.map(item => (
          <TodoItem 
            key={item.id} 
            item={item} 
            onToggle={onToggle}
          />
        ))}
      </ul>
    </div>
  );
});

const TodoItem = memo(({ item, onToggle }) => {
  console.log(`📋 TodoItem ${item.id} rendered`);
  
  return (
    <li style={{ 
      marginBottom: '8px', 
      padding: '10px', 
      backgroundColor: item.completed ? '#e8f5e8' : '#fff',
      border: '1px solid #ddd',
      borderRadius: '4px',
      display: 'flex',
      alignItems: 'center'
    }}>
      <input
        type="checkbox"
        checked={item.completed}
        onChange={() => onToggle(item.id)}
        style={{ marginRight: '10px' }}
      />
      <span style={{ 
        textDecoration: item.completed ? 'line-through' : 'none',
        color: item.completed ? '#666' : '#000'
      }}>
        {item.text}
      </span>
    </li>
  );
});

export default CompilerDemo;