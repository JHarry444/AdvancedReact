import { useState, useEffect } from 'react';

// Component demonstrating React 19 Compiler with more advanced patterns
const AdvancedCompilerDemo = () => {
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [loading, setLoading] = useState(false);

  // Simulate API call
  const fetchUsers = async () => {
    setLoading(true);
    // Simulated delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUsers = [
      { id: 1, name: 'Alice Johnson', email: 'alice@example.com', role: 'Developer', active: true },
      { id: 2, name: 'Bob Smith', email: 'bob@example.com', role: 'Designer', active: true },
      { id: 3, name: 'Charlie Brown', email: 'charlie@example.com', role: 'Manager', active: false },
      { id: 4, name: 'Diana Prince', email: 'diana@example.com', role: 'Developer', active: true },
      { id: 5, name: 'Eve Wilson', email: 'eve@example.com', role: 'Tester', active: true }
    ];
    
    setUsers(mockUsers);
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Complex filtering and sorting logic
  // React Compiler will automatically optimize this
  const processedUsers = users
    .filter(user => 
      user.name.toLowerCase().includes(filter.toLowerCase()) ||
      user.email.toLowerCase().includes(filter.toLowerCase()) ||
      user.role.toLowerCase().includes(filter.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'email':
          return a.email.localeCompare(b.email);
        case 'role':
          return a.role.localeCompare(b.role);
        default:
          return 0;
      }
    });

  // Complex derived state calculation
  const statistics = {
    total: users.length,
    active: users.filter(u => u.active).length,
    inactive: users.filter(u => u.active === false).length,
    roles: [...new Set(users.map(u => u.role))].length,
    filtered: processedUsers.length
  };

  const handleUserToggle = (id) => {
    setUsers(prev => prev.map(user =>
      user.id === id ? { ...user, active: !user.active } : user
    ));
  };

  const handleRefresh = () => {
    fetchUsers();
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1>🔬 Advanced React Compiler Demo</h1>
      
      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>User Management Dashboard</h2>
        
        <div style={{ display: 'flex', gap: '10px', marginBottom: '15px', flexWrap: 'wrap' }}>
          <input
            type="text"
            placeholder="Search users..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{ padding: '8px', flex: '1', minWidth: '200px' }}
          />
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{ padding: '8px' }}
          >
            <option value="name">Sort by Name</option>
            <option value="email">Sort by Email</option>
            <option value="role">Sort by Role</option>
          </select>
          
          <button onClick={handleRefresh} style={{ padding: '8px 16px' }}>
            {loading ? '🔄 Loading...' : '🔄 Refresh'}
          </button>
        </div>

        <UserStatistics stats={statistics} />
      </div>

      <div style={{ padding: '15px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h3>Users ({processedUsers.length})</h3>
        
        {loading ? (
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <p>Loading users... 🔄</p>
          </div>
        ) : (
          <UserList users={processedUsers} onToggle={handleUserToggle} />
        )}
      </div>

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f0f8ff', borderRadius: '8px' }}>
        <h3>🚀 Compiler Optimizations in Action:</h3>
        <ul>
          <li>✅ Complex filtering/sorting automatically memoized</li>
          <li>✅ Derived state calculations optimized</li>
          <li>✅ Event handlers automatically stable</li>
          <li>✅ Child components re-render only when needed</li>
          <li>✅ No manual optimization required!</li>
        </ul>
      </div>
    </div>
  );
};

const UserStatistics = ({ stats }) => {
  console.log('📊 UserStatistics rendered');
  
  return (
    <div style={{ 
      display: 'grid', 
      gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', 
      gap: '10px',
      marginBottom: '15px'
    }}>
      <StatCard label="Total" value={stats.total} color="#3498db" />
      <StatCard label="Active" value={stats.active} color="#27ae60" />
      <StatCard label="Inactive" value={stats.inactive} color="#e74c3c" />
      <StatCard label="Roles" value={stats.roles} color="#9b59b6" />
      <StatCard label="Filtered" value={stats.filtered} color="#f39c12" />
    </div>
  );
};

const StatCard = ({ label, value, color }) => (
  <div style={{
    padding: '10px',
    backgroundColor: color,
    color: 'white',
    borderRadius: '6px',
    textAlign: 'center'
  }}>
    <div style={{ fontSize: '18px', fontWeight: 'bold' }}>{value}</div>
    <div style={{ fontSize: '12px' }}>{label}</div>
  </div>
);

const UserList = ({ users, onToggle }) => {
  console.log('👥 UserList rendered');
  
  return (
    <div style={{ display: 'grid', gap: '10px' }}>
      {users.map(user => (
        <UserCard key={user.id} user={user} onToggle={onToggle} />
      ))}
      {users.length === 0 && (
        <p style={{ textAlign: 'center', color: '#666', padding: '20px' }}>
          No users found matching your criteria.
        </p>
      )}
    </div>
  );
};

const UserCard = ({ user, onToggle }) => {
  console.log(`👤 UserCard ${user.id} rendered`);
  
  return (
    <div style={{
      padding: '15px',
      border: '1px solid #ddd',
      borderRadius: '6px',
      backgroundColor: user.active ? '#fff' : '#f8f8f8',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }}>
      <div>
        <h4 style={{ margin: '0 0 5px 0' }}>{user.name}</h4>
        <p style={{ margin: '0 0 5px 0', color: '#666' }}>{user.email}</p>
        <span style={{
          padding: '2px 8px',
          backgroundColor: '#e3f2fd',
          borderRadius: '12px',
          fontSize: '12px',
          color: '#1976d2'
        }}>
          {user.role}
        </span>
      </div>
      
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span style={{
          padding: '4px 8px',
          borderRadius: '12px',
          fontSize: '12px',
          backgroundColor: user.active ? '#e8f5e8' : '#ffebee',
          color: user.active ? '#2e7d32' : '#c62828'
        }}>
          {user.active ? 'Active' : 'Inactive'}
        </span>
        
        <button
          onClick={() => onToggle(user.id)}
          style={{
            padding: '6px 12px',
            border: 'none',
            borderRadius: '4px',
            backgroundColor: user.active ? '#f44336' : '#4caf50',
            color: 'white',
            cursor: 'pointer'
          }}
        >
          {user.active ? 'Deactivate' : 'Activate'}
        </button>
      </div>
    </div>
  );
};

export default AdvancedCompilerDemo;