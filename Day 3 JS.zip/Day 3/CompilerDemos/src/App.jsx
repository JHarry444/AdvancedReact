import { useState } from 'react'
import CompilerDemo from './components/CompilerDemo'
import AdvancedCompilerDemo from './components/AdvancedCompilerDemo'
import PerformanceDemo from './components/PerformanceDemo'
import './App.css'

function App() {
  const [activeDemo, setActiveDemo] = useState('basic')

  const demos = {
    basic: { component: CompilerDemo, title: 'Basic Compiler Demo' },
    advanced: { component: AdvancedCompilerDemo, title: 'Advanced Compiler Demo' },
    performance: { component: PerformanceDemo, title: 'Performance Demo' }
  }

  const ActiveComponent = demos[activeDemo].component

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f5f5f5' }}>
      <header style={{ 
        backgroundColor: '#282c34', 
        padding: '20px', 
        color: 'white',
        textAlign: 'center',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h1 style={{ margin: '0 0 20px 0' }}>🚀 React 19 Compiler Showcase</h1>
        
        <nav style={{ display: 'flex', justifyContent: 'center', gap: '15px', flexWrap: 'wrap' }}>
          {Object.entries(demos).map(([key, demo]) => (
            <button
              key={key}
              onClick={() => setActiveDemo(key)}
              style={{
                padding: '10px 20px',
                border: 'none',
                borderRadius: '6px',
                backgroundColor: activeDemo === key ? '#61dafb' : '#404854',
                color: activeDemo === key ? '#000' : '#fff',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 'bold',
                transition: 'all 0.2s ease'
              }}
            >
              {demo.title}
            </button>
          ))}
        </nav>
      </header>

      <main>
        <ActiveComponent />
      </main>

      <footer style={{
        backgroundColor: '#282c34',
        color: 'white',
        padding: '20px',
        textAlign: 'center',
        marginTop: '40px'
      }}>
        <p style={{ margin: 0 }}>
          Built with React 19 + React Compiler | 
          Open Developer Console to see optimization logs! 📊
        </p>
      </footer>
    </div>
  )
}

export default App
