# React 19 Compiler - Quick Start Commands

## 🚀 Getting Started

### 1. Start the Development Server
```bash
cd updates
npm run dev
```

### 2. Open Your Browser
Navigate to: `http://localhost:5173`

### 3. Open Developer Console  
Press `F12` or `Ctrl+Shift+I` to see optimization logs

## 📊 What You'll See

The demo includes three main sections:

### 1. **Basic Compiler Demo**
- Counter with expensive calculations
- Todo list management
- Name input with dynamic content
- **Watch for**: Automatic memoization of expensive operations

### 2. **Advanced Compiler Demo**  
- User management dashboard
- Complex filtering and sorting
- Real-time statistics
- **Watch for**: Smart re-rendering and derived state optimization

### 3. **Performance Demo**
- Heavy data processing (1000+ items)
- Filter and sort operations
- Force re-render testing
- **Watch for**: Console logs showing optimization in action

## 🔍 Key Things to Test

1. **In Basic Demo:**
   - Click "Increment Count" - notice expensive calculation doesn't re-run unnecessarily
   - Add/remove todos - see how child components optimize
   - Type in name field - watch selective re-rendering

2. **In Advanced Demo:**
   - Search for users - notice filtering optimization
   - Change sort order - see smart re-calculation
   - Toggle user status - observe targeted updates

3. **In Performance Demo:**
   - Click "Force Re-render" - see what actually re-runs
   - Filter items - notice processing optimization
   - Click "Regenerate Data" - watch heavy operations

## 💡 Console Messages to Look For

- `🔥 Expensive calculation running...` - Shows when heavy ops actually run
- `📝 TodoList rendered` - Component render notifications
- `📊 Processing data...` - Data processing operations
- `👤 UserCard X rendered` - Individual component renders

## 🧪 Experiment Ideas

1. **Break the optimization:** Try to force unnecessary re-renders
2. **Add complexity:** Create your own components in the demos  
3. **Compare performance:** Temporarily disable the compiler and see the difference
4. **Profile components:** Use React DevTools Profiler

## 🛠️ Compiler Configuration

Your project is already configured with:
- React 19.2.0
- babel-plugin-react-compiler 19.1.0-rc.3
- Vite with React Compiler plugin

## 📚 Additional Resources

- [React 19 Documentation](https://react.dev)
- [React Compiler Playground](https://playground.react.dev)
- [React DevTools](https://chrome.google.com/webstore/detail/react-developer-tools)

---

**Ready to explore? Run `npm run dev` and start the demo! 🎉**