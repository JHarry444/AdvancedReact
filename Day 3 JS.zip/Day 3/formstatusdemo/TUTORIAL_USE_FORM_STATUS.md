# useFormStatus Hook Tutorial

## 🎯 Learning Objectives
By the end of this tutorial, you will understand:
- How to use the `useFormStatus` hook to access form submission status
- The relationship between `useFormStatus` and form actions
- How to create rich user interfaces with real-time form feedback
- Component architecture patterns for form status management
- Best practices for form UX with status indicators

## 📋 Prerequisites
- Basic knowledge of React hooks (useState, useEffect)
- Understanding of HTML forms and form submission
- Familiarity with the `useActionState` hook (covered in previous tutorial)
- Knowledge of component composition patterns
- Basic understanding of FormData API

## 🚀 Getting Started

### Step 1: Navigate to the Project
```bash
cd "c:\Users\Uswer\Desktop\React19Updates\formstatusdemo"
```

### Step 2: Install Dependencies (if needed)
```bash
npm install
```

### Step 3: Start the Development Server
```bash
npm run dev
```

### Step 4: Open Your Browser
Navigate to the displayed URL (usually `http://localhost:5173`)

### Step 5: Launch the Demo
Click "🚀 Launch useFormStatus Demo" to access the tutorial examples

## 📚 Tutorial Structure

This tutorial contains three comprehensive examples:

### 1. **Newsletter Subscription** - Basic Form Status Tracking
### 2. **Contact Form** - Advanced Status Display with Progress
### 3. **Feedback Form** - Complex Form with Rating System

---

## 🔍 Important: Understanding useFormStatus Architecture

### **Key Rule:**
`useFormStatus` **MUST** be called inside a component that is a **child** of a `<form>` element, not in the same component that renders the form.

### **Why This Matters:**
```javascript
// ❌ WRONG - useFormStatus in same component as form
function MyForm() {
  const { pending } = useFormStatus(); // This won't work!
  
  return (
    <form action={submitAction}>
      <input name="email" />
      <button disabled={pending}>Submit</button>
    </form>
  );
}

// ✅ CORRECT - useFormStatus in child component
function MyForm() {
  return (
    <form action={submitAction}>
      <input name="email" />
      <SubmitButton /> {/* Child component uses useFormStatus */}
    </form>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus(); // This works!
  return <button disabled={pending}>Submit</button>;
}
```

---

## 📧 Demo 1: Newsletter Subscription

### **What You'll Learn:**
- Basic `useFormStatus` hook usage
- Real-time form status tracking
- Accessing form data during submission
- Building responsive submit buttons

### **Key Concepts:**
- **Pending State:** Know when form is being submitted
- **Data Access:** Access FormData during submission
- **Method Information:** Get form submission method
- **Component Separation:** Proper architecture patterns

### **Hook API:**
```javascript
const { pending, data, method, action } = useFormStatus();
```

**Returns:**
- `pending`: Boolean - true when form is being submitted
- `data`: FormData - the data being submitted (only during submission)
- `method`: String - HTTP method (usually "post" for actions)
- `action`: String - form action URL or function reference

### **Hands-On Activities:**

#### Activity 1: Basic Status Tracking
1. Fill in name and email in the newsletter form
2. Click "📧 Subscribe to Newsletter"
3. **🔍 Observe:** Button immediately changes to "⏳ Subscribing..."
4. **📊 Watch:** Form status box shows real-time information
5. **⏱️ Wait:** 2.5 seconds for processing simulation
6. **💡 Key Learning:** Form status updates automatically

#### Activity 2: Real-time Data Access
1. **Before submitting:** Notice status shows "Ready"
2. **While submitting:** Watch the status box display:
   - Name and email being submitted
   - Method information
   - Pending state indicators
3. **🔍 Console:** Check browser console for logged form data
4. **💡 Key Learning:** Access to form data during submission

#### Activity 3: Error Handling (15% failure rate)
1. Submit multiple newsletter subscriptions
2. **🎯 Eventually:** Experience a failure (15% chance)
3. **🔍 Observe:** Form remains usable after errors
4. **📱 Notice:** Status resets to "Ready" after failure
5. **💡 Key Learning:** Status management during error states

### **Code Analysis:**
```javascript
const NewsletterSubmitButton = () => {
  const { pending, data, method, action } = useFormStatus();
  
  // Log status information
  console.log('Form Status:', { 
    pending, 
    data: data ? Object.fromEntries(data) : null, 
    method 
  });

  return (
    <div>
      <button type="submit" disabled={pending}>
        {pending ? 'Subscribing...' : 'Subscribe to Newsletter'}
      </button>
      
      {/* Real-time status display */}
      <div>
        <div>Status: {pending ? 'Submitting...' : 'Ready'}</div>
        {pending && data && (
          <div>Submitting: {data.get('name')} ({data.get('email')})</div>
        )}
        <div>Method: {method || 'Not submitted'}</div>
      </div>
    </div>
  );
};
```

### **Discussion Points:**
- Why must `useFormStatus` be in a child component?
- How does `data` access help with user feedback?
- What are the benefits of real-time status tracking?

---

## 📞 Demo 2: Contact Form with Advanced Status

### **What You'll Learn:**
- Advanced form status display patterns
- Progress indicators and animations
- Multi-field form status tracking
- Complex form validation feedback

### **Key Concepts:**
- **Progress Visualization:** Visual feedback during submission
- **Multi-field Tracking:** Status for complex forms
- **Detailed Feedback:** Rich status information display
- **Animation Integration:** Progress bars and loading states

### **Hands-On Activities:**

#### Activity 1: Complete Contact Form Submission
1. Fill in all fields: Name, Email, Subject, Message
2. Click "📞 Send Message"
3. **🔍 Observe:** Advanced status display shows:
   - Sender information
   - Subject line
   - Message character count
   - Animated progress bar
4. **⏱️ Wait:** 3 seconds for processing
5. **💡 Key Learning:** Rich status feedback during submission

#### Activity 2: Form Validation Testing
1. **Test 1:** Submit with missing name
   - **🔍 Error:** "Name is required"
2. **Test 2:** Submit with invalid email
   - **🔍 Error:** "Valid email is required"
3. **Test 3:** Submit with short subject (< 5 chars)
   - **🔍 Error:** "Subject must be at least 5 characters"
4. **Test 4:** Submit with short message (< 10 chars)
   - **🔍 Error:** "Message must be at least 10 characters"
5. **💡 Key Learning:** Status tracking with validation

#### Activity 3: Advanced Status Analysis (20% failure rate)
1. Submit valid contact forms multiple times
2. **📊 Watch:** Status details during submission:
   - Character counts
   - Progress animation
   - Method tracking
3. **🎯 Eventually:** Experience a failure
4. **🔍 Observe:** How status resets after errors
5. **💡 Key Learning:** Complex status management patterns

### **Code Analysis:**
```javascript
const ContactSubmitButton = () => {
  const { pending, data, method } = useFormStatus();

  return (
    <div>
      <button type="submit" disabled={pending}>
        {pending ? 'Sending Message...' : 'Send Message'}
      </button>

      {/* Advanced status display */}
      <div>
        <h4>Form Status Details</h4>
        <div>Status: {pending ? 'Processing' : 'Ready to submit'}</div>
        
        {pending && data && (
          <>
            <div>From: {data.get('name')} ({data.get('email')})</div>
            <div>Subject: {data.get('subject')}</div>
            <div>Message Length: {data.get('message')?.length || 0} characters</div>
            
            {/* Progress indicator */}
            <div className="progress-bar">
              <div className="progress-fill" />
            </div>
          </>
        )}
        
        <div>Method: {method || 'GET (default)'}</div>
      </div>
    </div>
  );
};
```

### **Discussion Points:**
- How do progress indicators improve user experience?
- What information is most valuable to show during submission?
- How can you handle long-running form submissions?

---

## 💬 Demo 3: Feedback Form with Rating System

### **What You'll Learn:**
- Complex form interactions with `useFormStatus`
- Radio button and select field status tracking
- Rating system integration
- Feedback collection patterns

### **Key Concepts:**
- **Rating Systems:** Status tracking with star ratings
- **Category Selection:** Dropdown integration with status
- **Feedback History:** Building submission lists
- **Complex Data Display:** Rich status information

### **Hands-On Activities:**

#### Activity 1: Complete Feedback Submission
1. Select a rating (1-5 stars)
2. Choose a category from dropdown
3. Write feedback message
4. Click "💬 Submit Feedback"
5. **🔍 Observe:** Status display shows:
   - Star rating preview
   - Selected category
   - Character count
6. **⏱️ Wait:** 1.8 seconds for processing
7. **📋 Success:** Feedback appears in history list
8. **💡 Key Learning:** Complex form data tracking

#### Activity 2: Rating and Category Testing
1. **Test different ratings:** Try each star level (1-5)
2. **Test categories:** Try different feedback categories
3. **🔍 Watch:** How status display adapts to selections
4. **📊 Notice:** Real-time preview of selections
5. **💡 Key Learning:** Status tracking with various input types

#### Activity 3: Feedback Validation (10% failure rate)
1. **Test 1:** Submit without rating
   - **🔍 Error:** "Please select a rating from 1-5"
2. **Test 2:** Submit without category
   - **🔍 Error:** "Please select a feedback category"
3. **Test 3:** Submit with short feedback (< 5 chars)
   - **🔍 Error:** "Feedback must be at least 5 characters"
4. **🎯 Submit valid feedback multiple times** to see occasional failures
5. **💡 Key Learning:** Validation with complex form elements

### **Code Analysis:**
```javascript
const FeedbackSubmitButton = () => {
  const { pending, data, method } = useFormStatus();

  return (
    <div>
      <button type="submit" disabled={pending}>
        {pending ? 'Submitting Feedback...' : 'Submit Feedback'}
      </button>

      {/* Detailed status with rating preview */}
      <div>
        <div>Status: {pending ? 'Submitting feedback...' : 'Ready'}</div>
        
        {pending && data && (
          <>
            <div>
              Rating: {'⭐'.repeat(parseInt(data.get('rating')))} 
              ({data.get('rating')}/5)
            </div>
            <div>Category: {data.get('category')}</div>
            <div>
              Feedback Length: {data.get('feedback')?.length || 0} characters
            </div>
          </>
        )}
        
        <div>Method: {method || 'Not submitted'}</div>
      </div>
    </div>
  );
};
```

### **Discussion Points:**
- How do you handle different input types in status displays?
- What's the best way to preview user selections?
- How can status information improve form completion rates?

---

## 🧠 Deep Dive: useFormStatus Mechanics

### **Hook Implementation Pattern:**
```javascript
function MySubmitButton() {
  const formStatus = useFormStatus();
  
  // formStatus contains:
  // {
  //   pending: boolean,    // Is form currently submitting?
  //   data: FormData,      // Form data being submitted
  //   method: string,      // HTTP method
  //   action: string       // Action URL or function
  // }
  
  return (
    <button disabled={formStatus.pending}>
      {formStatus.pending ? 'Submitting...' : 'Submit'}
    </button>
  );
}
```

### **Component Architecture:**
```javascript
// Parent component renders form
function ContactForm() {
  const [state, submitAction] = useActionState(contactAction, initialState);
  
  return (
    <form action={submitAction}>
      <input name="email" />
      <input name="message" />
      
      {/* Child component uses useFormStatus */}
      <SubmitButton />
      <StatusDisplay />
    </form>
  );
}

// Child components access form status
function SubmitButton() {
  const { pending } = useFormStatus();
  return <button disabled={pending}>Submit</button>;
}

function StatusDisplay() {
  const { pending, data } = useFormStatus();
  return (
    <div>
      Status: {pending ? 'Submitting' : 'Ready'}
      {pending && data && <div>Email: {data.get('email')}</div>}
    </div>
  );
}
```

### **Data Access Patterns:**
```javascript
function FormStatusDisplay() {
  const { pending, data } = useFormStatus();
  
  if (!pending || !data) {
    return <div>Form ready for submission</div>;
  }
  
  // Access individual form fields
  const email = data.get('email');
  const message = data.get('message');
  
  // Convert all data to object for logging
  const allData = Object.fromEntries(data);
  console.log('Submitting:', allData);
  
  return (
    <div>
      <div>Submitting...</div>
      <div>Email: {email}</div>
      <div>Message: {message?.substring(0, 50)}...</div>
    </div>
  );
}
```

---

## 🎯 Practical Exercises

### Exercise 1: Login Form with Status
Create a login form that:
- Shows username/password during submission
- Displays connection status
- Has a progress indicator
- Handles authentication errors

### Exercise 2: Multi-step Form Status
Build a multi-step form with:
- Status tracking across steps
- Progress visualization
- Step-specific status information
- Validation feedback per step

### Exercise 3: File Upload with Progress
Implement a file upload form that:
- Shows file information during upload
- Displays upload progress
- Handles file validation errors
- Shows upload completion status

---

## ⚡ Best Practices

### 1. **Component Architecture:**
```javascript
// ✅ Good: Separate status components
function MyForm() {
  return (
    <form action={submitAction}>
      <input name="email" />
      <SubmitButton />      {/* Uses useFormStatus */}
      <StatusDisplay />     {/* Uses useFormStatus */}
    </form>
  );
}

// ❌ Bad: Status in same component as form
function MyForm() {
  const { pending } = useFormStatus(); // Won't work!
  return <form>...</form>;
}
```

### 2. **Status Display Design:**
```javascript
function StatusDisplay() {
  const { pending, data } = useFormStatus();
  
  return (
    <div className={`status ${pending ? 'submitting' : 'ready'}`}>
      <div>Status: {pending ? '⏳ Processing' : '✅ Ready'}</div>
      
      {pending && data && (
        <div className="submission-details">
          <div>Submitting: {data.get('email')}</div>
          <div>Message: {data.get('message')?.length} characters</div>
        </div>
      )}
    </div>
  );
}
```

### 3. **Error State Management:**
```javascript
function FormWithStatus() {
  const [state, submitAction] = useActionState(myAction, initialState);
  
  return (
    <form action={submitAction}>
      {/* Show errors above form */}
      {state.error && (
        <div className="error">{state.error}</div>
      )}
      
      <input name="email" />
      <SubmitButtonWithStatus />
    </form>
  );
}
```

### 4. **Accessibility Considerations:**
```javascript
function AccessibleSubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button 
      type="submit" 
      disabled={pending}
      aria-busy={pending}
      aria-describedby="status-display"
    >
      {pending ? 'Submitting...' : 'Submit'}
    </button>
  );
}
```

---

## 🔧 Troubleshooting

### Common Issues:

1. **useFormStatus not working?**
   - ✅ Ensure it's called in a child component of `<form>`
   - ✅ Check that parent has a form with action
   - ✅ Verify React 19 is installed

2. **data is always null?**
   - ✅ Make sure form is actually submitting
   - ✅ Check that inputs have `name` attributes
   - ✅ Verify form has proper action

3. **pending never becomes true?**
   - ✅ Ensure form action is an async function
   - ✅ Check that form submission isn't being prevented
   - ✅ Verify action function is properly defined

4. **Status doesn't reset after submission?**
   - ✅ Make sure action function completes properly
   - ✅ Check for unhandled errors in action
   - ✅ Verify state management is correct

### Debugging Tips:
- Use `console.log` in status components to track changes
- Check Network tab for actual form submissions
- Verify FormData contents with `Object.fromEntries(data)`
- Test with slow network to see pending states clearly

---

## 📖 Additional Resources

### Documentation:
- [React 19 useFormStatus Hook](https://react.dev/reference/react-dom/hooks/useFormStatus)
- [Form Actions in React](https://react.dev/reference/react-dom/components/form)
- [FormData API](https://developer.mozilla.org/en-US/docs/Web/API/FormData)

### Further Learning:
- Progressive enhancement with forms
- Accessibility in form design
- Advanced form validation patterns
- Server-side form handling

---

## ✅ Tutorial Completion Checklist

- [ ] Successfully ran all three form demos
- [ ] Observed real-time form status tracking
- [ ] Understood component architecture requirements
- [ ] Experienced data access during submission
- [ ] Tested validation and error scenarios
- [ ] Analyzed different status display patterns
- [ ] Built own form with useFormStatus (optional)
- [ ] Tested accessibility features (optional)

---

## 🎉 Congratulations!

You've mastered the `useFormStatus` hook! This powerful React 19 feature enables you to create sophisticated form interfaces with real-time status feedback, improving user experience and providing rich interaction patterns.

**Key Takeaways:**
- `useFormStatus` must be used in child components of forms
- Provides real-time access to form submission status
- Enables rich user feedback during form processing
- Works seamlessly with `useActionState` for complete form solutions
- Improves accessibility and user experience
- Perfect for modern web application form patterns

The `useFormStatus` hook represents a significant advancement in React form handling, enabling developers to create responsive, informative, and user-friendly form experiences with minimal complexity.

Happy form building! 🚀