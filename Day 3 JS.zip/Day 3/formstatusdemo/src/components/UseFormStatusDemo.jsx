import { useState, useTransition } from 'react';

// Note: useFormStatus is primarily designed for Server Components in Next.js
// This demo shows the concept using client-side alternatives
// In a real Next.js app with Server Actions, you would import:
// import { useFormStatus } from 'react-dom';

// Custom hook to simulate useFormStatus behavior for demo purposes
const useFormStatusDemo = (isPending = false) => {
  // In a real Server Component environment, useFormStatus would return:
  // { pending: boolean, data: FormData | null, method: string, action: string | Function }
  
  return {
    pending: isPending,
    data: null, // Would contain FormData in real implementation
    method: 'POST',
    action: null // Would contain the action function/URL
  };
};

// Simulated API functions with delays and failures
const simulateDelay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const mockAPI = {
  // Simulate newsletter subscription
  subscribeNewsletter: async (prevState, formData) => {
    console.log('📧 Subscribing to newsletter:', Object.fromEntries(formData));
    await simulateDelay(2500);
    
    const email = formData.get('email');
    const name = formData.get('name');
    
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Please enter a valid email address', data: null };
    }
    
    if (!name || name.length < 2) {
      return { success: false, error: 'Name must be at least 2 characters', data: null };
    }
    
    // Simulate failures (15% chance)
    if (Math.random() < 0.15) {
      return { success: false, error: 'Subscription failed. Please try again.', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: { email, name, subscribedAt: new Date().toISOString() }
    };
  },

  // Simulate contact form submission
  submitContactForm: async (prevState, formData) => {
    console.log('📞 Submitting contact form:', Object.fromEntries(formData));
    await simulateDelay(3000);
    
    const name = formData.get('name');
    const email = formData.get('email');
    const subject = formData.get('subject');
    const message = formData.get('message');
    
    if (!name || name.length < 2) {
      return { success: false, error: 'Name is required', data: null };
    }
    
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Valid email is required', data: null };
    }
    
    if (!subject || subject.length < 5) {
      return { success: false, error: 'Subject must be at least 5 characters', data: null };
    }
    
    if (!message || message.length < 10) {
      return { success: false, error: 'Message must be at least 10 characters', data: null };
    }
    
    // Simulate failures (20% chance)
    if (Math.random() < 0.2) {
      return { success: false, error: 'Failed to send message. Please try again.', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: { name, email, subject, message, submittedAt: new Date().toISOString() }
    };
  },

  // Simulate user feedback form
  submitFeedback: async (prevState, formData) => {
    console.log('💬 Submitting feedback:', Object.fromEntries(formData));
    await simulateDelay(1800);
    
    const rating = parseInt(formData.get('rating'));
    const feedback = formData.get('feedback');
    const category = formData.get('category');
    
    if (!rating || rating < 1 || rating > 5) {
      return { success: false, error: 'Please select a rating from 1-5', data: null };
    }
    
    if (!feedback || feedback.length < 5) {
      return { success: false, error: 'Feedback must be at least 5 characters', data: null };
    }
    
    if (!category) {
      return { success: false, error: 'Please select a feedback category', data: null };
    }
    
    // Simulate failures (10% chance)
    if (Math.random() < 0.1) {
      return { success: false, error: 'Feedback submission failed. Please try again.', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: { rating, feedback, category, submittedAt: new Date().toISOString() }
    };
  }
};

const UseFormStatusDemo = () => {
  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h1>🚀 useFormStatus Hook Demo - React 19</h1>
      
      <div style={{ 
        marginBottom: '30px', 
        padding: '20px', 
        backgroundColor: '#e3f2fd', 
        borderRadius: '8px',
        border: '1px solid #2196f3'
      }}>
        <h2>💡 What is useFormStatus?</h2>
        <p>
          The <code>useFormStatus</code> hook provides access to the status information of a form 
          submission. It's designed to work with Server Actions and gives you:
        </p>
        <ul>
          <li>✅ <strong>Pending State:</strong> Know when a form is being submitted</li>
          <li>✅ <strong>Form Data Access:</strong> Access the data being submitted</li>
          <li>✅ <strong>Action Method:</strong> Information about the form submission method</li>
          <li>✅ <strong>Child Component Access:</strong> Use in components inside the form</li>
          <li>✅ <strong>Server Action Integration:</strong> Perfect for Next.js server actions</li>
        </ul>
        <div style={{ 
          marginTop: '15px', 
          padding: '10px', 
          backgroundColor: '#fff3e0', 
          borderRadius: '4px',
          border: '1px solid #ff9800'
        }}>
          <strong>⚠️ Important:</strong> <code>useFormStatus</code> must be called inside a component 
          that is a child of a <code>&lt;form&gt;</code> element, not in the same component that renders the form.
        </div>
        <div style={{ 
          marginTop: '15px', 
          padding: '10px', 
          backgroundColor: '#e8f5e8', 
          borderRadius: '4px',
          border: '1px solid #4caf50'
        }}>
          <strong>📝 Demo Note:</strong> This demo simulates <code>useFormStatus</code> behavior using client-side 
          code. In a real Next.js app with Server Actions, you would import <code>useFormStatus</code> from 
          <code>react-dom</code> and use it with actual server actions.
        </div>
      </div>

      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', 
        gap: '25px',
        marginBottom: '30px'
      }}>
        <NewsletterSubscription />
        <ContactForm />
        <FeedbackForm />
      </div>

      <div style={{ 
        padding: '20px', 
        backgroundColor: '#f5f5f5', 
        borderRadius: '8px' 
      }}>
        <h3>🎯 Key Benefits of useFormStatus:</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '15px' }}>
          <div>
            <h4>🔄 Real-time Status</h4>
            <p>Know exactly when forms are being processed</p>
          </div>
          <div>
            <h4>📊 Data Access</h4>
            <p>Access form data during submission</p>
          </div>
          <div>
            <h4>🎨 Rich UI Feedback</h4>
            <p>Create sophisticated loading states and progress indicators</p>
          </div>
          <div>
            <h4>🏗️ Component Separation</h4>
            <p>Separate form logic from UI components cleanly</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Example 1: Newsletter Subscription (simulating useFormStatus concept)
const NewsletterSubscription = () => {
  const [state, setState] = useState({ success: false, error: null, data: null });
  const [subscribers, setSubscribers] = useState([]);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    startTransition(async () => {
      const result = await mockAPI.subscribeNewsletter(null, formData);
      setState(result);
      if (result.success) {
        event.target.reset();
      }
    });
  };

  // Add successful subscriptions to the list
  if (state.success && state.data && !subscribers.find(sub => sub.email === state.data.email)) {
    setSubscribers(prev => [...prev, state.data]);
  }

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #4caf50', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>📧 Newsletter Subscription</h3>
      
      {state.success && state.data && (
        <div style={{
          padding: '15px',
          backgroundColor: '#e8f5e8',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #4caf50'
        }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#2e7d32' }}>✅ Subscription Successful!</h4>
          <p style={{ margin: '5px 0' }}><strong>Name:</strong> {state.data.name}</p>
          <p style={{ margin: '5px 0' }}><strong>Email:</strong> {state.data.email}</p>
          <p style={{ margin: '5px 0' }}><strong>Subscribed:</strong> {new Date(state.data.subscribedAt).toLocaleString()}</p>
        </div>
      )}

      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="newsletter-name" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Full Name:
          </label>
          <input
            id="newsletter-name"
            name="name"
            type="text"
            placeholder="Enter your name"
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              boxSizing: 'border-box'
            }}
          />
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="newsletter-email" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Email Address:
          </label>
          <input
            id="newsletter-email"
            name="email"
            type="email"
            placeholder="Enter your email"
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              boxSizing: 'border-box'
            }}
          />
        </div>

        {/* This component demonstrates form status concept */}
        <NewsletterSubmitButton pending={isPending} formData={null} />
      </form>

      {subscribers.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>📋 Recent Subscribers ({subscribers.length})</h4>
          <div style={{ maxHeight: '120px', overflowY: 'auto' }}>
            {subscribers.map((sub, index) => (
              <div key={index} style={{
                padding: '8px',
                backgroundColor: '#e8f5e8',
                borderRadius: '4px',
                marginBottom: '6px',
                border: '1px solid #4caf50',
                fontSize: '12px'
              }}>
                <strong>{sub.name}</strong> ({sub.email})
                <div style={{ color: '#666' }}>
                  {new Date(sub.subscribedAt).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// useFormStatus must be used in a child component of the form
const NewsletterSubmitButton = ({ pending: propsPending, formData }) => {
  // Using our demo version of useFormStatus (React 19 feature)
  // In a real Next.js app, you would import useFormStatus from 'react-dom'
  const { pending, data, method, action } = useFormStatusDemo(propsPending);
  
  // The actual submission state
  const isSubmitting = propsPending;
  
  console.log('📧 Newsletter Form Status:', { 
    pending: isSubmitting, 
    data: data ? Object.fromEntries(data) : null,
    method,
    action,
    formData: formData ? Object.fromEntries(formData) : null
  });

  return (
    <div>
      <button
        type="submit"
        disabled={isSubmitting}
        style={{
          width: '100%',
          padding: '12px',
          backgroundColor: isSubmitting ? '#ccc' : '#4caf50',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          fontSize: '16px',
          fontWeight: 'bold',
          cursor: isSubmitting ? 'not-allowed' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        }}
      >
        {isSubmitting ? (
          <>
            <span>⏳</span>
            <span>Subscribing...</span>
          </>
        ) : (
          <>
            <span>📧</span>
            <span>Subscribe to Newsletter</span>
          </>
        )}
      </button>
      
      {/* Real-time form status display */}
      <div style={{ 
        marginTop: '10px', 
        fontSize: '12px', 
        color: '#666',
        padding: '8px',
        backgroundColor: '#f9f9f9',
        borderRadius: '4px'
      }}>
        <div><strong>Form Status:</strong> {isSubmitting ? '⏳ Submitting...' : '✅ Ready'}</div>
        {isSubmitting && data && (
          <div><strong>Submitting:</strong> {data.get('name')} ({data.get('email')})</div>
        )}
        <div><strong>Method:</strong> {method || 'Not submitted'}</div>
        <div><strong>Action:</strong> {action ? 'Custom Action' : 'Default'}</div>
      </div>
    </div>
  );
};

// Example 2: Contact Form (simulating useFormStatus concept)
const ContactForm = () => {
  const [state, setState] = useState({ success: false, error: null, data: null });
  const [isPending, startTransition] = useTransition();

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    startTransition(async () => {
      const result = await mockAPI.submitContactForm(null, formData);
      setState(result);
      if (result.success) {
        event.target.reset();
      }
    });
  };

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #2196f3', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>📞 Contact Form</h3>
      
      {state.success && state.data && (
        <div style={{
          padding: '15px',
          backgroundColor: '#e3f2fd',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #2196f3'
        }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#1976d2' }}>✅ Message Sent Successfully!</h4>
          <p style={{ margin: '5px 0' }}><strong>From:</strong> {state.data.name} ({state.data.email})</p>
          <p style={{ margin: '5px 0' }}><strong>Subject:</strong> {state.data.subject}</p>
          <p style={{ margin: '5px 0' }}><strong>Sent:</strong> {new Date(state.data.submittedAt).toLocaleString()}</p>
        </div>
      )}

      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
          <div>
            <label htmlFor="contact-name" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Name:
            </label>
            <input
              id="contact-name"
              name="name"
              type="text"
              placeholder="Your name"
              required
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                fontSize: '14px',
                boxSizing: 'border-box'
              }}
            />
          </div>
          <div>
            <label htmlFor="contact-email" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Email:
            </label>
            <input
              id="contact-email"
              name="email"
              type="email"
              placeholder="your@email.com"
              required
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                fontSize: '14px',
                boxSizing: 'border-box'
              }}
            />
          </div>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="contact-subject" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Subject:
          </label>
          <input
            id="contact-subject"
            name="subject"
            type="text"
            placeholder="What's this about?"
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              boxSizing: 'border-box'
            }}
          />
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="contact-message" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Message:
          </label>
          <textarea
            id="contact-message"
            name="message"
            rows={4}
            placeholder="Your message here..."
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              resize: 'vertical',
              boxSizing: 'border-box'
            }}
          />
        </div>

        <ContactSubmitButton pending={isPending} formData={null} />
      </form>
    </div>
  );
};

const ContactSubmitButton = ({ pending: propsPending, formData }) => {
  // Using our demo version of useFormStatus (React 19 feature)
  // In a real Next.js app, you would import useFormStatus from 'react-dom'
  const { pending, data, method, action } = useFormStatusDemo(propsPending);
  
  // The actual submission state
  const isSubmitting = propsPending;
  
  console.log('📞 Contact Form Status:', { 
    pending: isSubmitting, 
    data: data ? Object.fromEntries(data) : null,
    method,
    action,
    formData: formData ? Object.fromEntries(formData) : null
  });

  return (
    <div>
      <button
        type="submit"
        disabled={isSubmitting}
        style={{
          width: '100%',
          padding: '12px',
          backgroundColor: isSubmitting ? '#ccc' : '#2196f3',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          fontSize: '16px',
          fontWeight: 'bold',
          cursor: isSubmitting ? 'not-allowed' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        }}
      >
        {isSubmitting ? (
          <>
            <span>⏳</span>
            <span>Sending Message...</span>
          </>
        ) : (
          <>
            <span>📞</span>
            <span>Send Message</span>
          </>
        )}
      </button>

      {/* Advanced status display with progress indicator */}
      <div style={{ 
        marginTop: '15px', 
        padding: '12px',
        backgroundColor: '#f5f5f5',
        borderRadius: '6px',
        border: '1px solid #ddd'
      }}>
        <h4 style={{ margin: '0 0 10px 0', fontSize: '14px' }}>📊 Form Status Details</h4>
        <div style={{ fontSize: '12px', marginBottom: '8px' }}>
          <span style={{ fontWeight: 'bold' }}>Status:</span> {isSubmitting ? '⏳ Processing' : '✅ Ready to submit'}
        </div>
        {isSubmitting && data && (
          <>
            <div style={{ fontSize: '12px', marginBottom: '8px' }}>
              <span style={{ fontWeight: 'bold' }}>From:</span> {data.get('name')} ({data.get('email')})
            </div>
            <div style={{ fontSize: '12px', marginBottom: '8px' }}>
              <span style={{ fontWeight: 'bold' }}>Subject:</span> {data.get('subject')}
            </div>
            <div style={{ fontSize: '12px', marginBottom: '8px' }}>
              <span style={{ fontWeight: 'bold' }}>Message Length:</span> {data.get('message')?.length || 0} characters
            </div>
            {/* Simple progress indicator */}
            <div style={{
              width: '100%',
              height: '6px',
              backgroundColor: '#e0e0e0',
              borderRadius: '3px',
              overflow: 'hidden'
            }}>
              <div style={{
                width: '100%',
                height: '100%',
                backgroundColor: '#2196f3',
                animation: 'progress 3s linear infinite'
              }} />
            </div>
          </>
        )}
        <div style={{ fontSize: '12px', color: '#666' }}>
          <span style={{ fontWeight: 'bold' }}>Method:</span> {method || 'GET (default)'}
        </div>
        <div style={{ fontSize: '12px', color: '#666' }}>
          <span style={{ fontWeight: 'bold' }}>Action:</span> {action ? 'Custom Action' : 'Default'}
        </div>
      </div>

      {/* CSS for progress animation - using CSS-in-JS approach */}
      <style>
        {`
          @keyframes progress {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
          }
        `}
      </style>
    </div>
  );
};

// Example 3: Feedback Form with Rating System
const FeedbackForm = () => {
  const [state, setState] = useState({ success: false, error: null, data: null });
  const [feedbackList, setFeedbackList] = useState([]);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    startTransition(async () => {
      const result = await mockAPI.submitFeedback(null, formData);
      setState(result);
      if (result.success) {
        event.target.reset();
      }
    });
  };

  // Add successful feedback to the list
  if (state.success && state.data && !feedbackList.find(fb => fb.submittedAt === state.data.submittedAt)) {
    setFeedbackList(prev => [...prev, state.data]);
  }

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #ff9800', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>💬 Feedback Form</h3>
      
      {state.success && state.data && (
        <div style={{
          padding: '15px',
          backgroundColor: '#fff3e0',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #ff9800'
        }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#f57c00' }}>✅ Feedback Submitted!</h4>
          <p style={{ margin: '5px 0' }}><strong>Rating:</strong> {'⭐'.repeat(state.data.rating)} ({state.data.rating}/5)</p>
          <p style={{ margin: '5px 0' }}><strong>Category:</strong> {state.data.category}</p>
          <p style={{ margin: '5px 0' }}><strong>Submitted:</strong> {new Date(state.data.submittedAt).toLocaleString()}</p>
        </div>
      )}

      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
            Rating (1-5 stars):
          </label>
          <div style={{ 
            display: 'flex', 
            gap: '15px', 
            flexWrap: 'wrap',
            alignItems: 'center'
          }}>
            {[1, 2, 3, 4, 5].map(rating => (
              <label key={rating} style={{ 
                display: 'flex', 
                alignItems: 'center', 
                cursor: 'pointer',
                whiteSpace: 'nowrap'
              }}>
                <input
                  type="radio"
                  name="rating"
                  value={rating}
                  style={{ marginRight: '8px' }}
                  required
                />
                <span>{rating} ⭐</span>
              </label>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="feedback-category" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Category:
          </label>
          <select
            id="feedback-category"
            name="category"
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              boxSizing: 'border-box'
            }}
          >
            <option value="">Select category...</option>
            <option value="Bug Report">Bug Report</option>
            <option value="Feature Request">Feature Request</option>
            <option value="General Feedback">General Feedback</option>
            <option value="User Experience">User Experience</option>
            <option value="Performance">Performance</option>
          </select>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="feedback-message" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Your Feedback:
          </label>
          <textarea
            id="feedback-message"
            name="feedback"
            rows={3}
            placeholder="Tell us what you think..."
            required
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              resize: 'vertical',
              boxSizing: 'border-box'
            }}
          />
        </div>

        <FeedbackSubmitButton pending={isPending} formData={null} />
      </form>

      {feedbackList.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>📋 Recent Feedback ({feedbackList.length})</h4>
          <div style={{ maxHeight: '150px', overflowY: 'auto' }}>
            {feedbackList.map((fb, index) => (
              <div key={index} style={{
                padding: '10px',
                backgroundColor: '#fff3e0',
                borderRadius: '4px',
                marginBottom: '8px',
                border: '1px solid #ff9800',
                fontSize: '12px'
              }}>
                <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
                  {'⭐'.repeat(fb.rating)} ({fb.rating}/5) - {fb.category}
                </div>
                <div style={{ marginBottom: '4px' }}>{fb.feedback}</div>
                <div style={{ color: '#666' }}>{new Date(fb.submittedAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const FeedbackSubmitButton = ({ pending: propsPending, formData }) => {
  // Using our demo version of useFormStatus (React 19 feature)
  // In a real Next.js app, you would import useFormStatus from 'react-dom'
  const { pending, data, method, action } = useFormStatusDemo(propsPending);
  
  // The actual submission state
  const isSubmitting = propsPending;
  
  console.log('💬 Feedback Form Status:', { 
    pending: isSubmitting, 
    data: data ? Object.fromEntries(data) : null,
    method,
    action,
    formData: formData ? Object.fromEntries(formData) : null
  });

  return (
    <div>
      <button
        type="submit"
        disabled={isSubmitting}
        style={{
          width: '100%',
          padding: '12px',
          backgroundColor: isSubmitting ? '#ccc' : '#ff9800',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          fontSize: '16px',
          fontWeight: 'bold',
          cursor: isSubmitting ? 'not-allowed' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        }}
      >
        {isSubmitting ? (
          <>
            <span>⏳</span>
            <span>Submitting Feedback...</span>
          </>
        ) : (
          <>
            <span>💬</span>
            <span>Submit Feedback</span>
          </>
        )}
      </button>

      {/* Detailed status with rating preview */}
      <div style={{ 
        marginTop: '12px', 
        fontSize: '12px', 
        color: '#666',
        padding: '10px',
        backgroundColor: '#fafafa',
        borderRadius: '4px',
        border: '1px solid #e0e0e0'
      }}>
        <div><strong>Status:</strong> {isSubmitting ? '⏳ Submitting feedback...' : '✅ Ready'}</div>
        {isSubmitting && data && (
          <>
            <div><strong>Rating:</strong> {'⭐'.repeat(parseInt(data.get('rating')))} ({data.get('rating')}/5)</div>
            <div><strong>Category:</strong> {data.get('category')}</div>
            <div><strong>Feedback Length:</strong> {data.get('feedback')?.length || 0} characters</div>
          </>
        )}
        <div><strong>Method:</strong> {method || 'Not submitted'}</div>
        <div><strong>Action:</strong> {action ? 'Custom Action' : 'Default'}</div>
      </div>
    </div>
  );
};

export default UseFormStatusDemo;