import { useState } from 'react'
import UseFormStatusDemo from './components/UseFormStatusDemo'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [showDemo, setShowDemo] = useState(false)

  if (showDemo) {
    return <UseFormStatusDemo />
  }

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>React 19 - useFormStatus Hook</h1>
      <div className="card">
        <button 
          onClick={() => setShowDemo(true)}
          style={{
            padding: '12px 24px',
            fontSize: '16px',
            backgroundColor: '#646cff',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}
        >
          🚀 Launch useFormStatus Demo
        </button>
        <p>
          Click the button above to see the <code>useFormStatus</code> hook in action!
        </p>
        <div style={{ 
          marginTop: '20px', 
          padding: '15px', 
          backgroundColor: '#f0f8ff', 
          borderRadius: '8px',
          textAlign: 'left'
        }}>
          <h3>What you'll see:</h3>
          <ul style={{ paddingLeft: '20px' }}>
            <li>📧 <strong>Newsletter Subscription:</strong> Real-time form status tracking</li>
            <li>📞 <strong>Contact Form:</strong> Advanced status display with progress</li>
            <li>💬 <strong>Feedback Form:</strong> Rating system with detailed status</li>
            <li>🔄 <strong>Form Status Access:</strong> Pending state, data access, and method info</li>
          </ul>
        </div>
      </div>
      <p className="read-the-docs">
        The useFormStatus hook provides real-time access to form submission status
      </p>
    </>
  )
}

export default App
