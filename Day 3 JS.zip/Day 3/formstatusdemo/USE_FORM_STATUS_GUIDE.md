# useFormStatus Hook Guide - React 19

## 🚀 What is useFormStatus?

The `useFormStatus` hook is a React 19 feature that provides access to the status information of a form submission. It's designed to work with form actions and enables rich user interfaces with real-time form feedback.

## 📖 Basic Syntax

```javascript
import { useFormStatus } from 'react-dom';

const { pending, data, method, action } = useFormStatus();
```

### Returns:
- **`pending`**: Boolean indicating if the form is currently being submitted
- **`data`**: FormData object containing the form data being submitted (only during submission)
- **`method`**: String representing the HTTP method (usually "post" for actions)
- **`action`**: String or function reference representing the form action

## 🔍 Critical Architecture Rule

**`useFormStatus` MUST be called inside a component that is a child of a `<form>` element, not in the same component that renders the form.**

### ❌ Wrong Usage:
```javascript
function MyForm() {
  const { pending } = useFormStatus(); // This won't work!
  
  return (
    <form action={submitAction}>
      <input name="email" />
      <button disabled={pending}>Submit</button>
    </form>
  );
}
```

### ✅ Correct Usage:
```javascript
function MyForm() {
  return (
    <form action={submitAction}>
      <input name="email" />
      <SubmitButton /> {/* Child component uses useFormStatus */}
    </form>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus(); // This works!
  return (
    <button type="submit" disabled={pending}>
      {pending ? 'Submitting...' : 'Submit'}
    </button>
  );
}
```

## 🎯 Key Benefits

1. **🔄 Real-time Status**: Know exactly when forms are being processed
2. **📊 Data Access**: Access form data during submission for rich feedback
3. **🎨 Rich UI**: Create sophisticated loading states and progress indicators
4. **🏗️ Clean Architecture**: Separate form logic from UI components
5. **♿ Accessibility**: Better screen reader support and user feedback
6. **🚀 Server Actions**: Perfect integration with Next.js server actions

## 💡 Real-World Examples

### 1. Basic Submit Button with Status

```javascript
function SubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button 
      type="submit" 
      disabled={pending}
      style={{
        backgroundColor: pending ? '#ccc' : '#007bff',
        cursor: pending ? 'not-allowed' : 'pointer'
      }}
    >
      {pending ? '⏳ Submitting...' : '📤 Submit'}
    </button>
  );
}
```

### 2. Data Preview During Submission

```javascript
function FormDataPreview() {
  const { pending, data } = useFormStatus();
  
  if (!pending || !data) {
    return <div>Ready to submit</div>;
  }
  
  return (
    <div className="submission-preview">
      <h4>Submitting:</h4>
      <div>Email: {data.get('email')}</div>
      <div>Message: {data.get('message')?.substring(0, 50)}...</div>
    </div>
  );
}
```

### 3. Progress Indicator

```javascript
function ProgressIndicator() {
  const { pending, data } = useFormStatus();
  
  if (!pending) return null;
  
  return (
    <div className="progress-container">
      <div className="progress-bar">
        <div className="progress-fill animate-pulse" />
      </div>
      <div>Processing {data ? Object.keys(Object.fromEntries(data)).length : 0} fields...</div>
    </div>
  );
}
```

### 4. Complete Form with Status Components

```javascript
function ContactForm() {
  const [state, submitAction] = useActionState(contactAction, { 
    success: false, 
    error: null 
  });
  
  return (
    <form action={submitAction}>
      {state.error && (
        <div className="error-message">{state.error}</div>
      )}
      
      <input name="name" placeholder="Your Name" required />
      <input name="email" type="email" placeholder="Email" required />
      <textarea name="message" placeholder="Message" required />
      
      <div className="form-footer">
        <SubmitButton />
        <FormStatus />
      </div>
      
      {state.success && (
        <div className="success-message">Message sent successfully!</div>
      )}
    </form>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button type="submit" disabled={pending}>
      {pending ? 'Sending...' : 'Send Message'}
    </button>
  );
}

function FormStatus() {
  const { pending, data, method } = useFormStatus();
  
  return (
    <div className="form-status">
      <div>Status: {pending ? 'Submitting' : 'Ready'}</div>
      {pending && data && (
        <div>
          Sending message from {data.get('name')} ({data.get('email')})
        </div>
      )}
      <div>Method: {method || 'GET'}</div>
    </div>
  );
}
```

## 🔄 Common Patterns

### 1. Form Validation Feedback

```javascript
function ValidationStatus() {
  const { pending, data } = useFormStatus();
  
  if (!pending || !data) return null;
  
  const email = data.get('email');
  const isValidEmail = email && email.includes('@');
  
  return (
    <div className="validation-status">
      <div>Validating submission...</div>
      <div>Email: {isValidEmail ? '✅' : '❌'} {email}</div>
    </div>
  );
}
```

### 2. Multi-step Form Status

```javascript
function MultiStepStatus() {
  const { pending, data } = useFormStatus();
  
  if (!pending) return null;
  
  const currentStep = data?.get('currentStep') || '1';
  const totalSteps = 3;
  
  return (
    <div className="step-progress">
      <div>Processing Step {currentStep} of {totalSteps}</div>
      <div className="progress-bar">
        <div 
          className="progress-fill" 
          style={{ width: `${(currentStep / totalSteps) * 100}%` }}
        />
      </div>
    </div>
  );
}
```

### 3. File Upload Status

```javascript
function FileUploadStatus() {
  const { pending, data } = useFormStatus();
  
  if (!pending || !data) return null;
  
  const files = data.getAll('files');
  const totalSize = files.reduce((sum, file) => sum + file.size, 0);
  
  return (
    <div className="upload-status">
      <div>Uploading {files.length} file(s)...</div>
      <div>Total size: {(totalSize / 1024 / 1024).toFixed(2)} MB</div>
      <div className="upload-progress">
        <div className="progress-bar animate-pulse" />
      </div>
    </div>
  );
}
```

### 4. Real-time Character Counter

```javascript
function CharacterCounter({ fieldName, maxLength = 500 }) {
  const { data } = useFormStatus();
  
  const currentLength = data?.get(fieldName)?.length || 0;
  const remaining = maxLength - currentLength;
  
  return (
    <div className={`char-counter ${remaining < 50 ? 'warning' : ''}`}>
      {currentLength}/{maxLength} characters
      {remaining < 0 && <span className="error">Too long!</span>}
    </div>
  );
}
```

## 🎨 Advanced UI Patterns

### 1. Animated Submit Button

```javascript
function AnimatedSubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button 
      type="submit" 
      disabled={pending}
      className={`submit-btn ${pending ? 'submitting' : ''}`}
    >
      <span className="btn-text">
        {pending ? 'Sending' : 'Send Message'}
      </span>
      {pending && (
        <span className="spinner">
          <div className="spinner-ring" />
        </span>
      )}
    </button>
  );
}
```

### 2. Status Timeline

```javascript
function StatusTimeline() {
  const { pending, data } = useFormStatus();
  const [timeline, setTimeline] = useState([]);
  
  useEffect(() => {
    if (pending && data) {
      setTimeline(prev => [...prev, {
        timestamp: new Date(),
        action: 'Form submission started',
        data: Object.fromEntries(data)
      }]);
    }
  }, [pending, data]);
  
  return (
    <div className="status-timeline">
      {timeline.map((entry, index) => (
        <div key={index} className="timeline-entry">
          <div className="timestamp">
            {entry.timestamp.toLocaleTimeString()}
          </div>
          <div className="action">{entry.action}</div>
        </div>
      ))}
    </div>
  );
}
```

## 🔧 Integration with useActionState

`useFormStatus` works perfectly with `useActionState` for complete form solutions:

```javascript
// Action function
async function submitForm(prevState, formData) {
  const email = formData.get('email');
  const message = formData.get('message');
  
  try {
    await api.sendMessage({ email, message });
    return { success: true, error: null };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Form component
function CompleteForm() {
  const [state, submitAction] = useActionState(submitForm, {
    success: false,
    error: null
  });
  
  return (
    <form action={submitAction}>
      {state.error && <ErrorMessage error={state.error} />}
      {state.success && <SuccessMessage />}
      
      <input name="email" type="email" required />
      <textarea name="message" required />
      
      <SubmitWithStatus />
      <FormStatusDisplay />
    </form>
  );
}

function SubmitWithStatus() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending}>
      {pending ? 'Sending...' : 'Send'}
    </button>
  );
}

function FormStatusDisplay() {
  const { pending, data } = useFormStatus();
  
  return (
    <div>
      <div>Form Status: {pending ? 'Processing' : 'Ready'}</div>
      {pending && data && (
        <div>Sending: {data.get('email')}</div>
      )}
    </div>
  );
}
```

## ⚡ Best Practices

### 1. **Component Separation**
```javascript
// ✅ Good: Status components are children of form
function MyForm() {
  return (
    <form action={submitAction}>
      <FormFields />
      <SubmitButton />     {/* Uses useFormStatus */}
      <StatusDisplay />    {/* Uses useFormStatus */}
    </form>
  );
}

// ❌ Bad: Status in same component as form
function MyForm() {
  const { pending } = useFormStatus(); // Won't work
  return <form>...</form>;
}
```

### 2. **Conditional Rendering**
```javascript
function SmartStatusDisplay() {
  const { pending, data } = useFormStatus();
  
  // Only show during submission
  if (!pending) return null;
  
  return (
    <div className="submission-status">
      <div>Processing your request...</div>
      {data && <FormDataSummary data={data} />}
    </div>
  );
}
```

### 3. **Accessibility**
```javascript
function AccessibleSubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button 
      type="submit" 
      disabled={pending}
      aria-busy={pending}
      aria-describedby="form-status"
    >
      {pending ? 'Submitting...' : 'Submit'}
    </button>
  );
}

function AccessibleFormStatus() {
  const { pending } = useFormStatus();
  
  return (
    <div 
      id="form-status"
      role="status"
      aria-live="polite"
    >
      {pending ? 'Form is being submitted' : 'Form ready for submission'}
    </div>
  );
}
```

### 4. **Error Boundaries**
```javascript
function SafeFormStatus() {
  const { pending, data } = useFormStatus();
  
  try {
    return (
      <div>
        Status: {pending ? 'Submitting' : 'Ready'}
        {pending && data && (
          <div>Data: {JSON.stringify(Object.fromEntries(data))}</div>
        )}
      </div>
    );
  } catch (error) {
    console.error('FormStatus error:', error);
    return <div>Status unavailable</div>;
  }
}
```

## 🚨 Common Pitfalls

### 1. **Wrong Component Placement**
```javascript
// ❌ This will not work
function BadForm() {
  const { pending } = useFormStatus(); // Error: not in form child
  
  return (
    <form>
      <input name="email" />
      <button disabled={pending}>Submit</button>
    </form>
  );
}
```

### 2. **Missing Form Action**
```javascript
// ❌ Form without action won't trigger useFormStatus
<form> {/* Missing action prop */}
  <input name="email" />
  <SubmitButton /> {/* useFormStatus won't work */}
</form>

// ✅ Form with action
<form action={submitAction}>
  <input name="email" />
  <SubmitButton /> {/* useFormStatus works */}
</form>
```

### 3. **Data Access Timing**
```javascript
// ❌ Accessing data when not pending
function BadDataAccess() {
  const { data } = useFormStatus();
  
  // data is only available during submission
  const email = data.get('email'); // May be null
  
  return <div>Email: {email}</div>;
}

// ✅ Proper data access
function GoodDataAccess() {
  const { pending, data } = useFormStatus();
  
  if (!pending || !data) return null;
  
  const email = data.get('email');
  return <div>Submitting: {email}</div>;
}
```

## 🔍 When to Use useFormStatus

### ✅ Perfect For:
- Submit button states and loading indicators
- Real-time form data preview
- Progress indicators for long-running submissions
- Form validation feedback
- Multi-step form status tracking
- File upload progress
- Rich form user experiences

### ❌ Not Ideal For:
- Form validation (use controlled inputs instead)
- Data fetching on component mount
- State management outside of forms
- Complex application state

## 📚 Integration Examples

### Next.js Server Actions
```javascript
// app/actions.js (Server Action)
'use server'

export async function createPost(prevState, formData) {
  const title = formData.get('title');
  const content = formData.get('content');
  
  try {
    const post = await db.post.create({ data: { title, content } });
    return { success: true, data: post };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// app/components/PostForm.jsx (Client Component)
'use client'

import { useFormStatus, useActionState } from 'react';
import { createPost } from '../actions';

export function PostForm() {
  const [state, submitAction] = useActionState(createPost, {
    success: false,
    error: null
  });

  return (
    <form action={submitAction}>
      <input name="title" placeholder="Post title" required />
      <textarea name="content" placeholder="Post content" required />
      <SubmitButton />
      <FormStatus />
    </form>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  
  return (
    <button type="submit" disabled={pending}>
      {pending ? 'Creating Post...' : 'Create Post'}
    </button>
  );
}

function FormStatus() {
  const { pending, data } = useFormStatus();
  
  if (!pending) return null;
  
  return (
    <div>
      Creating post: "{data?.get('title')}"
    </div>
  );
}
```

---

**The useFormStatus hook represents a major advancement in React form handling, enabling rich, responsive form experiences with minimal complexity! 🚀**