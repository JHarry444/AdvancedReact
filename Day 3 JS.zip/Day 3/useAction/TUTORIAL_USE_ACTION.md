# useAction Hook Tutorial

## 🎯 Learning Objectives
By the end of this tutorial, you will understand:
- How to use the `useAction` hook for form handling and async operations
- Built-in state management for pending, success, and error states
- Progressive enhancement and accessibility benefits
- Integration with server actions and modern web development

## 📋 Prerequisites
- Basic knowledge of React hooks (useState, useEffect)
- Understanding of HTML forms and FormData
- Familiarity with async/await and Promises
- Basic knowledge of form validation
- Understanding of progressive enhancement concepts

## 🚀 Getting Started

### Step 1: Navigate to the Project
```bash
cd "c:\Users\Uswer\Desktop\React19Updates\useAction"
```

### Step 2: Install Dependencies (if needed)
```bash
npm install
```

### Step 3: Start the Development Server
```bash
npm run dev
```

### Step 4: Open Your Browser
Navigate to the displayed URL (usually `http://localhost:5173`)

### Step 5: Launch the Demo
Click "🚀 Launch useAction Demo" to access the tutorial examples

## 📚 Tutorial Structure

This tutorial contains three comprehensive examples:

### 1. **User Registration Form** - Form Validation and Error Handling
### 2. **Message Sender** - Async Operations with Complex UI States
### 3. **File Uploader** - File Handling and Progress Management

---

## 👤 Demo 1: User Registration Form

### **What You'll Learn:**
- Basic `useAction` hook usage with forms
- Built-in form validation and error handling
- Success state management and user feedback
- Progressive enhancement principles

### **Key Concepts:**
- **Action Function:** Server-side logic that processes FormData
- **Built-in States:** Automatic pending, success, and error state management
- **Form Integration:** Seamless HTML form integration
- **Progressive Enhancement:** Forms work without JavaScript

### **Hook Syntax:**
```javascript
const [state, submitAction, isPending] = useActionState(actionFunction, initialState);
```

### **Hands-On Activities:**

#### Activity 1: Successful Registration
1. Fill in valid name (2+ characters) and email
2. Click "✅ Register User"
3. **🔍 Observe:** Button changes to "⏳ Registering..." immediately
4. **⏱️ Wait:** 2 seconds for processing simulation
5. **🎉 Success:** Green success box appears with user details
6. **💡 Key Learning:** Built-in loading states and success handling

#### Activity 2: Form Validation Testing
1. **Test 1:** Submit with empty name
   - **🔍 Observe:** Red error box: "Name must be at least 2 characters"
2. **Test 2:** Submit with invalid email (no @ symbol)
   - **🔍 Observe:** Red error box: "Please enter a valid email address"
3. **Test 3:** Submit with single character name
   - **🔍 Observe:** Validation error appears
4. **💡 Key Learning:** Server-side validation with client feedback

#### Activity 3: Server Error Simulation (20% failure rate)
1. Submit valid data multiple times (try 5-10 times)
2. **🎯 Eventually:** See "Server error: Registration failed"
3. **🔍 Observe:** Form remains usable, no broken state
4. **💡 Key Learning:** Graceful error handling built-in

### **Code Analysis:**
```javascript
// Action function - runs on server/backend
const registerUser = async (prevState, formData) => {
  console.log('🚀 Registering user:', Object.fromEntries(formData));
  await simulateDelay(2000);
  
  const name = formData.get('name');
  const email = formData.get('email');
  
  // Server-side validation
  if (!name || name.length < 2) {
    return { success: false, error: 'Name must be at least 2 characters', data: null };
  }
  
  if (!email || !email.includes('@')) {
    return { success: false, error: 'Please enter a valid email address', data: null };
  }
  
  // Simulate server processing
  if (Math.random() < 0.2) {
    return { success: false, error: 'Server error: Registration failed', data: null };
  }
  
  return {
    success: true,
    error: null,
    data: {
      id: Date.now(),
      name,
      email,
      registeredAt: new Date().toISOString()
    }
  };
};

// Component using the hook
const [state, submitAction, isPending] = useActionState(registerUser, initialState);
```

### **Form Structure:**
```javascript
<form action={submitAction}>
  <input name="name" type="text" required disabled={isPending} />
  <input name="email" type="email" required disabled={isPending} />
  <button type="submit" disabled={isPending}>
    {isPending ? 'Registering...' : 'Register User'}
  </button>
</form>
```

### **Discussion Points:**
- How does `useAction` differ from traditional form handling?
- What are the benefits of server-side validation?
- How does progressive enhancement work with `useAction`?

---

## 💬 Demo 2: Message Sender

### **What You'll Learn:**
- Complex form interactions with multiple fields
- Dropdown selection and textarea handling
- Message history and state accumulation
- Advanced error scenarios

### **Key Concepts:**
- **Multi-field Forms:** Handling multiple form inputs
- **State Accumulation:** Building lists of successful submissions
- **Conditional UI:** Dynamic recipient selection
- **Message History:** Tracking sent messages

### **Hands-On Activities:**

#### Activity 1: Successful Message Sending
1. Select a recipient from the dropdown
2. Type a message (5+ characters required)
3. Click "📨 Send Message"
4. **🔍 Observe:** Button shows "⏳ Sending..." for 1.5 seconds
5. **📋 Notice:** Sent message appears in the history below
6. **💡 Key Learning:** State accumulation and success tracking

#### Activity 2: Validation Testing
1. **Test 1:** Try sending without selecting recipient
   - **🔍 Error:** "Please select a recipient"
2. **Test 2:** Type message with less than 5 characters
   - **🔍 Error:** "Message must be at least 5 characters"
3. **Test 3:** Leave message empty
   - **🔍 Error:** Validation prevents submission
4. **💡 Key Learning:** Multi-field validation patterns

#### Activity 3: Message History Building (15% failure rate)
1. Send multiple valid messages
2. **📊 Watch:** Messages accumulate in the sent list
3. **🎯 Notice:** Each message shows recipient and timestamp
4. **⚠️ Eventually:** Experience a failure (15% chance)
5. **🔍 Observe:** Failed messages don't appear in history
6. **💡 Key Learning:** Success state management

### **Code Analysis:**
```javascript
const sendMessage = async (prevState, formData) => {
  console.log('📨 Sending message:', Object.fromEntries(formData));
  await simulateDelay(1500);
  
  const message = formData.get('message');
  const recipient = formData.get('recipient');
  
  // Multi-field validation
  if (!message || message.length < 5) {
    return { success: false, error: 'Message must be at least 5 characters', data: null };
  }
  
  if (!recipient) {
    return { success: false, error: 'Please select a recipient', data: null };
  }
  
  // Simulate network failures
  if (Math.random() < 0.15) {
    return { success: false, error: 'Failed to send message. Please try again.', data: null };
  }
  
  return {
    success: true,
    error: null,
    data: {
      id: Date.now(),
      message,
      recipient,
      sentAt: new Date().toLocaleTimeString()
    }
  };
};
```

### **State Management Pattern:**
```javascript
// Track successful messages separately
const [sentMessages, setSentMessages] = useState([]);

// Add successful messages to history
if (state.success && state.data && !sentMessages.find(msg => msg.id === state.data.id)) {
  setSentMessages(prev => [...prev, state.data]);
}
```

### **Discussion Points:**
- How do you handle complex form validation?
- What's the best way to manage message history?
- How do you provide feedback for different error types?

---

## 📎 Demo 3: File Uploader

### **What You'll Learn:**
- File handling with `useAction`
- File size validation and restrictions
- Upload progress simulation
- File metadata management

### **Key Concepts:**
- **File Validation:** Size limits and type checking
- **Progress Indicators:** Long-running operation feedback
- **File Metadata:** Tracking uploaded file information
- **Error Recovery:** Handling upload failures gracefully

### **Hands-On Activities:**

#### Activity 1: Successful File Upload
1. Click "Choose File" and select any file
2. Optionally add a description
3. Click "📎 Upload File"
4. **🔍 Observe:** Button shows "⏳ Uploading..." for 3 seconds
5. **📁 Success:** Green box shows file details (name, size, timestamp)
6. **📋 Notice:** File appears in uploaded files list
7. **💡 Key Learning:** File processing and metadata handling

#### Activity 2: File Validation Testing
1. **Test 1:** Try uploading without selecting a file
   - **🔍 Error:** "Please select a file to upload"
2. **Test 2:** Create/find a file larger than 5MB (if possible)
   - **🔍 Error:** "File size must be less than 5MB"
3. **💡 Key Learning:** Client and server-side file validation

#### Activity 3: Upload History and Failures (25% failure rate)
1. Upload multiple files with descriptions
2. **📊 Watch:** Files accumulate in the uploaded list
3. **🎯 Try:** Upload 4-5 files to experience failures
4. **⚠️ Eventually:** See "Upload failed. Please try again."
5. **🔍 Observe:** Failed uploads don't appear in history
6. **💡 Key Learning:** File upload error handling

### **Code Analysis:**
```javascript
const uploadFile = async (prevState, formData) => {
  console.log('📎 Uploading file...');
  await simulateDelay(3000); // Longer delay for file upload
  
  const file = formData.get('file');
  const description = formData.get('description');
  
  // File validation
  if (!file || file.size === 0) {
    return { success: false, error: 'Please select a file to upload', data: null };
  }
  
  if (file.size > 5 * 1024 * 1024) { // 5MB limit
    return { success: false, error: 'File size must be less than 5MB', data: null };
  }
  
  // Simulate upload failures
  if (Math.random() < 0.25) {
    return { success: false, error: 'Upload failed. Please try again.', data: null };
  }
  
  return {
    success: true,
    error: null,
    data: {
      id: Date.now(),
      fileName: file.name,
      fileSize: file.size,
      description,
      uploadedAt: new Date().toISOString()
    }
  };
};
```

### **File Handling Pattern:**
```javascript
<input
  type="file"
  name="file"
  required
  disabled={isPending}
  // File validation happens both client and server-side
/>

// Display file information
{uploadedFiles.map(file => (
  <div key={file.id}>
    <strong>{file.fileName}</strong> ({(file.fileSize / 1024).toFixed(1)} KB)
    {file.description && <div>{file.description}</div>}
  </div>
))}
```

### **Discussion Points:**
- How do you handle large file uploads efficiently?
- What file validation should happen client vs. server-side?
- How do you provide progress feedback for long operations?

---

## 🧠 Deep Dive: useAction Architecture

### **Action Function Pattern:**
```javascript
async function myAction(prevState, formData) {
  // 1. Extract form data
  const field1 = formData.get('field1');
  const field2 = formData.get('field2');
  
  // 2. Validation
  if (!field1) {
    return { success: false, error: 'Field1 is required' };
  }
  
  // 3. Processing (API calls, database operations, etc.)
  try {
    const result = await api.processData(field1, field2);
    
    // 4. Success response
    return { success: true, data: result, error: null };
  } catch (error) {
    // 5. Error response
    return { success: false, error: error.message };
  }
}
```

### **State Management Pattern:**
```javascript
// Consistent state shape across all examples
const initialState = {
  success: false,  // Boolean: operation succeeded
  error: null,     // String: error message or null
  data: null       // Object: success data or null
};
```

### **Form Integration:**
```javascript
<form action={submitAction} method="post">
  {/* Form inputs with name attributes */}
  <input name="fieldName" />
  
  {/* Submit button with pending state */}
  <button type="submit" disabled={isPending}>
    {isPending ? 'Processing...' : 'Submit'}
  </button>
</form>
```

---

## 🎯 Practical Exercises

### Exercise 1: Login Form
Create a login form that:
- Validates email and password
- Shows loading states
- Handles authentication errors
- Redirects on success

### Exercise 2: Contact Form
Build a contact form with:
- Multiple field validation
- File attachment support
- Success confirmation
- Error recovery

### Exercise 3: Multi-step Form
Implement a multi-step form that:
- Validates each step
- Maintains progress state
- Handles step-by-step submission
- Provides completion feedback

---

## ⚡ Best Practices

### 1. **Action Function Design:**
```javascript
// ✅ Good: Consistent return shape
async function goodAction(prevState, formData) {
  try {
    const result = await processData(formData);
    return { success: true, data: result, error: null };
  } catch (error) {
    return { success: false, error: error.message, data: null };
  }
}

// ❌ Bad: Inconsistent return shape
async function badAction(prevState, formData) {
  if (error) return "Error occurred"; // Wrong type
  return { data: result }; // Missing success/error flags
}
```

### 2. **Form Validation:**
```javascript
// Validate both client and server-side
async function validateAndProcess(prevState, formData) {
  const email = formData.get('email');
  
  // Server-side validation (essential)
  if (!email || !email.includes('@')) {
    return { success: false, error: 'Valid email required' };
  }
  
  // Continue processing...
}
```

### 3. **Progressive Enhancement:**
```javascript
// Form works without JavaScript
<form action={submitAction} method="post">
  <input name="message" required />
  <button type="submit">Send</button>
</form>
```

### 4. **Error Handling:**
```javascript
// Provide helpful, user-friendly error messages
if (file.size > MAX_SIZE) {
  return { 
    success: false, 
    error: `File too large. Maximum size is ${MAX_SIZE / 1024 / 1024}MB` 
  };
}
```

---

## 🔧 Troubleshooting

### Common Issues:

1. **Action not firing?**
   - Check that form has `action={submitAction}` prop
   - Ensure button is `type="submit"`
   - Verify action function is properly defined

2. **Form data not accessible?**
   - Use `formData.get('fieldName')` not direct object access
   - Ensure input fields have `name` attributes
   - Check for typos in field names

3. **State not updating?**
   - Verify action function returns proper state shape
   - Check for consistent success/error/data structure
   - Ensure async operations are properly awaited

4. **Pending state issues?**
   - Use `disabled={isPending}` on form elements
   - Show loading indicators based on `isPending`
   - Don't manually manage loading state

### Debugging Tips:
- Use `console.log(Object.fromEntries(formData))` to inspect form data
- Check Network tab for actual requests (in real apps)
- Verify action function return values
- Test with slow network to see pending states

---

## 📖 Additional Resources

### Documentation:
- [React 19 useActionState Hook](https://react.dev/reference/react/useActionState)
- [Server Actions in Next.js](https://nextjs.org/docs/app/building-your-application/data-fetching/server-actions)
- [Progressive Enhancement](https://developer.mozilla.org/en-US/docs/Glossary/Progressive_Enhancement)

### Further Learning:
- Next.js Server Actions integration
- Form accessibility best practices
- File upload optimization techniques
- Error boundary integration

---

## ✅ Tutorial Completion Checklist

- [ ] Successfully ran all three form demos
- [ ] Tested form validation scenarios
- [ ] Experienced error handling and recovery
- [ ] Understood built-in state management
- [ ] Completed hands-on activities
- [ ] Analyzed action function patterns
- [ ] Built own form with useAction (optional)
- [ ] Tested progressive enhancement (optional)

---

## 🎉 Congratulations!

You've mastered the `useAction` hook! This powerful React 19 feature revolutionizes form handling by providing built-in state management, progressive enhancement, and seamless server integration.

**Key Takeaways:**
- `useAction` simplifies form handling dramatically
- Built-in pending, success, and error states
- Progressive enhancement works automatically
- Perfect for server actions and modern web apps
- Consistent patterns across all form types
- Better accessibility and user experience

The `useAction` hook represents the future of form handling in React, combining simplicity, power, and modern web standards. Happy form building! 🚀