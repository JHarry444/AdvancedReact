# useAction Hook Guide - React 19

## 🚀 What is useAction?

The `useAction` hook (also known as `useActionState`) is a powerful new React 19 feature designed to handle form submissions and async actions with built-in state management. It's particularly useful for:

- Form submissions
- Server actions (Next.js)
- Async operations with loading states
- Progressive enhancement
- Error handling

## 📖 Basic Syntax

```javascript
import { useActionState } from 'react';

const [state, dispatch, isPending] = useActionState(actionFunction, initialState);
```

### Parameters:
- **`actionFunction`**: An async function that receives `(prevState, formData)` and returns new state
- **`initialState`**: The initial state value

### Returns:
- **`state`**: Current state (result from last action)
- **`dispatch`**: Function to trigger the action (used as form's `action` prop)
- **`isPending`**: Boolean indicating if action is currently running

## 🎯 Key Benefits

1. **📝 Form Integration**: Works seamlessly with HTML forms and FormData
2. **🔄 Automatic State Management**: Handles pending, success, and error states
3. **🚀 Progressive Enhancement**: Forms work without JavaScript
4. **⚡ Server Actions**: Perfect for Next.js server actions
5. **🛡️ Built-in Error Handling**: Automatic error state management
6. **📱 Accessibility**: Maintains form semantics and screen reader support

## 💡 Real-World Examples

### 1. Basic Form Submission

```javascript
import { useActionState } from 'react';

// Action function
async function submitForm(prevState, formData) {
  const name = formData.get('name');
  const email = formData.get('email');
  
  try {
    const response = await fetch('/api/users', {
      method: 'POST',
      body: JSON.stringify({ name, email }),
    });
    
    if (!response.ok) {
      return { success: false, error: 'Failed to create user' };
    }
    
    const user = await response.json();
    return { success: true, data: user, error: null };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

function UserForm() {
  const initialState = { success: false, error: null, data: null };
  const [state, submitAction, isPending] = useActionState(submitForm, initialState);

  return (
    <form action={submitAction}>
      <input name="name" placeholder="Name" required />
      <input name="email" type="email" placeholder="Email" required />
      
      <button type="submit" disabled={isPending}>
        {isPending ? 'Creating...' : 'Create User'}
      </button>
      
      {state.error && <p style={{ color: 'red' }}>{state.error}</p>}
      {state.success && <p style={{ color: 'green' }}>User created successfully!</p>}
    </form>
  );
}
```

### 2. Message Sending with Validation

```javascript
async function sendMessage(prevState, formData) {
  const message = formData.get('message');
  const recipient = formData.get('recipient');
  
  // Validation
  if (!message || message.length < 5) {
    return { success: false, error: 'Message must be at least 5 characters' };
  }
  
  if (!recipient) {
    return { success: false, error: 'Please select a recipient' };
  }
  
  try {
    await fetch('/api/messages', {
      method: 'POST',
      body: JSON.stringify({ message, recipient }),
    });
    
    return { 
      success: true, 
      data: { message, recipient, sentAt: new Date().toISOString() },
      error: null 
    };
  } catch (error) {
    return { success: false, error: 'Failed to send message' };
  }
}

function MessageForm() {
  const [state, submitAction, isPending] = useActionState(sendMessage, {
    success: false,
    error: null,
    data: null
  });

  return (
    <form action={submitAction}>
      <select name="recipient" required>
        <option value="">Select recipient...</option>
        <option value="alice@example.com">Alice</option>
        <option value="bob@example.com">Bob</option>
      </select>
      
      <textarea 
        name="message" 
        placeholder="Type your message..." 
        required 
      />
      
      <button type="submit" disabled={isPending}>
        {isPending ? 'Sending...' : 'Send Message'}
      </button>
      
      {state.error && (
        <div style={{ color: 'red' }}>Error: {state.error}</div>
      )}
      
      {state.success && (
        <div style={{ color: 'green' }}>
          Message sent to {state.data.recipient} at {state.data.sentAt}
        </div>
      )}
    </form>
  );
}
```

### 3. File Upload with Progress

```javascript
async function uploadFile(prevState, formData) {
  const file = formData.get('file');
  const description = formData.get('description');
  
  if (!file || file.size === 0) {
    return { success: false, error: 'Please select a file' };
  }
  
  if (file.size > 5 * 1024 * 1024) { // 5MB
    return { success: false, error: 'File too large (max 5MB)' };
  }
  
  try {
    const uploadFormData = new FormData();
    uploadFormData.append('file', file);
    uploadFormData.append('description', description);
    
    const response = await fetch('/api/upload', {
      method: 'POST',
      body: uploadFormData,
    });
    
    if (!response.ok) {
      throw new Error('Upload failed');
    }
    
    const result = await response.json();
    return { 
      success: true, 
      data: { ...result, fileName: file.name, fileSize: file.size },
      error: null 
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

function FileUploadForm() {
  const [state, submitAction, isPending] = useActionState(uploadFile, {
    success: false,
    error: null,
    data: null
  });

  return (
    <form action={submitAction}>
      <input type="file" name="file" required />
      <input type="text" name="description" placeholder="File description" />
      
      <button type="submit" disabled={isPending}>
        {isPending ? 'Uploading...' : 'Upload File'}
      </button>
      
      {isPending && <progress />}
      
      {state.error && (
        <div style={{ color: 'red' }}>Upload failed: {state.error}</div>
      )}
      
      {state.success && (
        <div style={{ color: 'green' }}>
          File "{state.data.fileName}" uploaded successfully!
          Size: {(state.data.fileSize / 1024).toFixed(1)} KB
        </div>
      )}
    </form>
  );
}
```

## 🔄 Action Function Pattern

The action function receives two parameters:

```javascript
async function myAction(prevState, formData) {
  // prevState: Previous state returned by this function
  // formData: FormData object from the form submission
  
  // Extract form data
  const field1 = formData.get('field1');
  const field2 = formData.get('field2');
  
  // Validation
  if (!field1) {
    return { success: false, error: 'Field1 is required' };
  }
  
  try {
    // Async operation
    const result = await api.doSomething(field1, field2);
    
    // Return new state
    return { success: true, data: result, error: null };
  } catch (error) {
    return { success: false, error: error.message };
  }
}
```

## ⚡ Best Practices

### 1. Consistent State Shape
```javascript
// Use a consistent state structure
const initialState = {
  success: false,
  error: null,
  data: null,
  // Additional fields as needed
};
```

### 2. Proper Error Handling
```javascript
async function actionWithErrorHandling(prevState, formData) {
  try {
    // Your logic here
    return { success: true, data: result, error: null };
  } catch (error) {
    console.error('Action failed:', error);
    return { 
      success: false, 
      error: error.message || 'Something went wrong',
    };
  }
}
```

### 3. Form Validation
```javascript
async function actionWithValidation(prevState, formData) {
  const email = formData.get('email');
  const password = formData.get('password');
  
  // Client-side validation
  if (!email || !email.includes('@')) {
    return { success: false, error: 'Please enter a valid email' };
  }
  
  if (!password || password.length < 8) {
    return { success: false, error: 'Password must be at least 8 characters' };
  }
  
  // Continue with action...
}
```

### 4. Progressive Enhancement
```javascript
// Form works without JavaScript!
<form action={submitAction} method="post">
  <input name="message" required />
  <button type="submit">Send</button>
</form>
```

## 🔍 When to Use useAction

### ✅ Perfect For:
- Form submissions
- User authentication
- File uploads
- Creating/updating resources
- Server actions in Next.js
- Any async operation triggered by user input

### ❌ Not Ideal For:
- Data fetching on component mount (use `useEffect` + `fetch`)
- Real-time data updates (use `useEffect` + WebSockets)
- Complex state management (consider `useReducer` or state management library)

## 🛠️ Next.js Server Actions Example

```javascript
// app/actions.js (Server Action)
'use server'

export async function createPost(prevState, formData) {
  const title = formData.get('title');
  const content = formData.get('content');
  
  try {
    const post = await db.post.create({
      data: { title, content }
    });
    
    return { success: true, data: post };
  } catch (error) {
    return { success: false, error: 'Failed to create post' };
  }
}

// app/components/PostForm.jsx (Client Component)
'use client'

import { useActionState } from 'react';
import { createPost } from '../actions';

export function PostForm() {
  const [state, submitAction, isPending] = useActionState(createPost, {
    success: false,
    error: null
  });

  return (
    <form action={submitAction}>
      <input name="title" placeholder="Post title" required />
      <textarea name="content" placeholder="Post content" required />
      <button type="submit" disabled={isPending}>
        {isPending ? 'Creating...' : 'Create Post'}
      </button>
    </form>
  );
}
```

## 🧪 Testing Tips

1. **Test with and without JavaScript** to ensure progressive enhancement
2. **Test validation** by submitting invalid data
3. **Test network failures** by simulating API errors
4. **Test rapid submissions** to ensure proper pending state handling
5. **Test accessibility** with screen readers

## 📚 Comparison with Other Hooks

| Feature | useAction | useState + useEffect | useReducer |
|---------|-----------|---------------------|------------|
| Form Integration | ✅ Built-in | ❌ Manual | ❌ Manual |
| Pending State | ✅ Automatic | ❌ Manual | ❌ Manual |
| Progressive Enhancement | ✅ Yes | ❌ No | ❌ No |
| Error Handling | ✅ Built-in | ❌ Manual | ❌ Manual |
| Server Actions | ✅ Perfect | ❌ Complex | ❌ Complex |

---

**The useAction hook revolutionizes form handling in React by providing a complete solution for async operations with built-in state management! 🎉**