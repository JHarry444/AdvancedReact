import { useActionState, useState } from 'react';

// Simulated API functions with delays and occasional failures
const simulateDelay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const mockAPI = {
  // Simulate user registration
  registerUser: async (prevState, formData) => {
    console.log('🚀 Registering user:', Object.fromEntries(formData));
    await simulateDelay(2000);
    
    const name = formData.get('name');
    const email = formData.get('email');
    
    // Validate data
    if (!name || name.length < 2) {
      return { success: false, error: 'Name must be at least 2 characters', data: null };
    }
    
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Please enter a valid email address', data: null };
    }
    
    // Simulate occasional failures
    if (Math.random() < 0.2) {
      return { success: false, error: 'Server error: Registration failed', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: {
        id: Date.now(),
        name,
        email,
        registeredAt: new Date().toISOString()
      }
    };
  },

  // Simulate sending a message
  sendMessage: async (prevState, formData) => {
    console.log('📨 Sending message:', Object.fromEntries(formData));
    await simulateDelay(1500);
    
    const message = formData.get('message');
    const recipient = formData.get('recipient');
    
    if (!message || message.length < 5) {
      return { success: false, error: 'Message must be at least 5 characters', data: null };
    }
    
    if (!recipient) {
      return { success: false, error: 'Please select a recipient', data: null };
    }
    
    // Simulate failures
    if (Math.random() < 0.15) {
      return { success: false, error: 'Failed to send message. Please try again.', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: {
        id: Date.now(),
        message,
        recipient,
        sentAt: new Date().toLocaleTimeString()
      }
    };
  },

  // Simulate file upload
  uploadFile: async (prevState, formData) => {
    console.log('📎 Uploading file...');
    await simulateDelay(3000);
    
    const file = formData.get('file');
    const description = formData.get('description');
    
    if (!file || file.size === 0) {
      return { success: false, error: 'Please select a file to upload', data: null };
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      return { success: false, error: 'File size must be less than 5MB', data: null };
    }
    
    // Simulate failures
    if (Math.random() < 0.25) {
      return { success: false, error: 'Upload failed. Please try again.', data: null };
    }
    
    return {
      success: true,
      error: null,
      data: {
        id: Date.now(),
        fileName: file.name,
        fileSize: file.size,
        description,
        uploadedAt: new Date().toISOString()
      }
    };
  }
};

const UseActionDemo = () => {
  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h1>🚀 useAction Hook Demo - React 19</h1>
      
      <div style={{ 
        marginBottom: '30px', 
        padding: '20px', 
        backgroundColor: '#e3f2fd', 
        borderRadius: '8px',
        border: '1px solid #2196f3'
      }}>
        <h2>💡 What is useAction?</h2>
        <p>
          The <code>useAction</code> (also called <code>useActionState</code>) hook is designed to handle 
          form submissions and async actions with built-in state management. It provides:
        </p>
        <ul>
          <li>✅ <strong>Pending State:</strong> Automatic loading states during async operations</li>
          <li>✅ <strong>Error Handling:</strong> Built-in error state management</li>
          <li>✅ <strong>Form Integration:</strong> Seamless integration with HTML forms</li>
          <li>✅ <strong>Progressive Enhancement:</strong> Works without JavaScript</li>
          <li>✅ <strong>Server Actions:</strong> Perfect for Next.js server actions</li>
        </ul>
      </div>

      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', 
        gap: '25px',
        marginBottom: '30px'
      }}>
        <UserRegistrationForm />
        <MessageSender />
        <FileUploader />
      </div>

      <div style={{ 
        padding: '20px', 
        backgroundColor: '#f5f5f5', 
        borderRadius: '8px' 
      }}>
        <h3>🎯 Key Benefits of useAction:</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '15px' }}>
          <div>
            <h4>🔄 Automatic State Management</h4>
            <p>Handles pending, success, and error states automatically</p>
          </div>
          <div>
            <h4>📝 Form Integration</h4>
            <p>Works seamlessly with HTML forms and FormData</p>
          </div>
          <div>
            <h4>🚀 Progressive Enhancement</h4>
            <p>Forms work even without JavaScript enabled</p>
          </div>
          <div>
            <h4>⚡ Server Actions</h4>
            <p>Perfect for Next.js server actions and full-stack apps</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Example 1: User Registration Form
const UserRegistrationForm = () => {
  const initialState = { success: false, error: null, data: null };
  const [state, submitAction, isPending] = useActionState(mockAPI.registerUser, initialState);

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #4caf50', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>👤 User Registration</h3>
      
      {state.success && (
        <div style={{
          padding: '15px',
          backgroundColor: '#e8f5e8',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #4caf50'
        }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#2e7d32' }}>✅ Registration Successful!</h4>
          <p style={{ margin: '5px 0' }}><strong>ID:</strong> {state.data.id}</p>
          <p style={{ margin: '5px 0' }}><strong>Name:</strong> {state.data.name}</p>
          <p style={{ margin: '5px 0' }}><strong>Email:</strong> {state.data.email}</p>
          <p style={{ margin: '5px 0' }}><strong>Registered:</strong> {new Date(state.data.registeredAt).toLocaleString()}</p>
        </div>
      )}

      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form action={submitAction}>
        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="name" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Full Name:
          </label>
          <input
            id="name"
            name="name"
            type="text"
            placeholder="Enter your full name"
            required
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              opacity: isPending ? 0.6 : 1
            }}
          />
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="email" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Email Address:
          </label>
          <input
            id="email"
            name="email"
            type="email"
            placeholder="Enter your email"
            required
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              opacity: isPending ? 0.6 : 1
            }}
          />
        </div>

        <button
          type="submit"
          disabled={isPending}
          style={{
            width: '100%',
            padding: '12px',
            backgroundColor: isPending ? '#ccc' : '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: 'bold',
            cursor: isPending ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
        >
          {isPending ? (
            <>
              <span>⏳</span>
              <span>Registering...</span>
            </>
          ) : (
            <>
              <span>✅</span>
              <span>Register User</span>
            </>
          )}
        </button>
      </form>

      <div style={{ marginTop: '15px', fontSize: '12px', color: '#666' }}>
        💡 <strong>Tip:</strong> Try submitting with invalid data to see error handling!
      </div>
    </div>
  );
};

// Example 2: Message Sender
const MessageSender = () => {
  const initialState = { success: false, error: null, data: null };
  const [state, submitAction, isPending] = useActionState(mockAPI.sendMessage, initialState);
  const [sentMessages, setSentMessages] = useState([]);

  // Add successful messages to the list
  if (state.success && state.data && !sentMessages.find(msg => msg.id === state.data.id)) {
    setSentMessages(prev => [...prev, state.data]);
  }

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #2196f3', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>💬 Message Sender</h3>
      
      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form action={submitAction}>
        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="recipient" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Recipient:
          </label>
          <select
            id="recipient"
            name="recipient"
            required
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              opacity: isPending ? 0.6 : 1
            }}
          >
            <option value="">Select recipient...</option>
            <option value="alice@example.com">Alice (alice@example.com)</option>
            <option value="bob@example.com">Bob (bob@example.com)</option>
            <option value="charlie@example.com">Charlie (charlie@example.com)</option>
          </select>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="message" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Message:
          </label>
          <textarea
            id="message"
            name="message"
            placeholder="Type your message here..."
            rows={4}
            required
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              resize: 'vertical',
              opacity: isPending ? 0.6 : 1
            }}
          />
        </div>

        <button
          type="submit"
          disabled={isPending}
          style={{
            width: '100%',
            padding: '12px',
            backgroundColor: isPending ? '#ccc' : '#2196f3',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: 'bold',
            cursor: isPending ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
        >
          {isPending ? (
            <>
              <span>⏳</span>
              <span>Sending...</span>
            </>
          ) : (
            <>
              <span>📨</span>
              <span>Send Message</span>
            </>
          )}
        </button>
      </form>

      {sentMessages.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>📨 Sent Messages ({sentMessages.length})</h4>
          <div style={{ maxHeight: '150px', overflowY: 'auto' }}>
            {sentMessages.map(msg => (
              <div key={msg.id} style={{
                padding: '10px',
                backgroundColor: '#e3f2fd',
                borderRadius: '4px',
                marginBottom: '8px',
                border: '1px solid #2196f3'
              }}>
                <div style={{ fontSize: '12px', color: '#1976d2', marginBottom: '4px' }}>
                  To: {msg.recipient} | Sent: {msg.sentAt}
                </div>
                <div style={{ fontSize: '14px' }}>{msg.message}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Example 3: File Uploader
const FileUploader = () => {
  const initialState = { success: false, error: null, data: null };
  const [state, submitAction, isPending] = useActionState(mockAPI.uploadFile, initialState);
  const [uploadedFiles, setUploadedFiles] = useState([]);

  // Add successful uploads to the list
  if (state.success && state.data && !uploadedFiles.find(file => file.id === state.data.id)) {
    setUploadedFiles(prev => [...prev, state.data]);
  }

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #ff9800', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>📎 File Uploader</h3>
      
      {state.success && state.data && (
        <div style={{
          padding: '15px',
          backgroundColor: '#e8f5e8',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #4caf50'
        }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#2e7d32' }}>✅ Upload Successful!</h4>
          <p style={{ margin: '5px 0' }}><strong>File:</strong> {state.data.fileName}</p>
          <p style={{ margin: '5px 0' }}><strong>Size:</strong> {(state.data.fileSize / 1024).toFixed(1)} KB</p>
          <p style={{ margin: '5px 0' }}><strong>Uploaded:</strong> {new Date(state.data.uploadedAt).toLocaleString()}</p>
        </div>
      )}

      {state.error && (
        <div style={{
          padding: '15px',
          backgroundColor: '#ffebee',
          borderRadius: '6px',
          marginBottom: '15px',
          border: '1px solid #f44336'
        }}>
          <p style={{ margin: 0, color: '#c62828' }}>❌ <strong>Error:</strong> {state.error}</p>
        </div>
      )}

      <form action={submitAction}>
        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="file" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Select File:
          </label>
          <input
            id="file"
            name="file"
            type="file"
            required
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              opacity: isPending ? 0.6 : 1
            }}
          />
          <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
            Maximum file size: 5MB
          </div>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="description" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Description (Optional):
          </label>
          <input
            id="description"
            name="description"
            type="text"
            placeholder="Describe your file..."
            disabled={isPending}
            style={{
              width: '100%',
              padding: '10px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              fontSize: '14px',
              opacity: isPending ? 0.6 : 1
            }}
          />
        </div>

        <button
          type="submit"
          disabled={isPending}
          style={{
            width: '100%',
            padding: '12px',
            backgroundColor: isPending ? '#ccc' : '#ff9800',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: 'bold',
            cursor: isPending ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
        >
          {isPending ? (
            <>
              <span>⏳</span>
              <span>Uploading...</span>
            </>
          ) : (
            <>
              <span>📎</span>
              <span>Upload File</span>
            </>
          )}
        </button>
      </form>

      {uploadedFiles.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>📁 Uploaded Files ({uploadedFiles.length})</h4>
          <div style={{ maxHeight: '120px', overflowY: 'auto' }}>
            {uploadedFiles.map(file => (
              <div key={file.id} style={{
                padding: '8px',
                backgroundColor: '#fff3e0',
                borderRadius: '4px',
                marginBottom: '6px',
                border: '1px solid #ff9800',
                fontSize: '12px'
              }}>
                <strong>{file.fileName}</strong> ({(file.fileSize / 1024).toFixed(1)} KB)
                {file.description && <div style={{ color: '#666' }}>{file.description}</div>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default UseActionDemo;