import { useState } from 'react'
import UseActionDemo from './components/UseActionDemo'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [showDemo, setShowDemo] = useState(false)

  if (showDemo) {
    return <UseActionDemo />
  }

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>React 19 - useAction Hook</h1>
      <div className="card">
        <button 
          onClick={() => setShowDemo(true)}
          style={{
            padding: '12px 24px',
            fontSize: '16px',
            backgroundColor: '#646cff',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}
        >
          🚀 Launch useAction Demo
        </button>
        <p>
          Click the button above to see the <code>useAction</code> hook in action!
        </p>
        <div style={{ 
          marginTop: '20px', 
          padding: '15px', 
          backgroundColor: '#f0f8ff', 
          borderRadius: '8px',
          textAlign: 'left'
        }}>
          <h3>What you'll see:</h3>
          <ul style={{ paddingLeft: '20px' }}>
            <li>👤 <strong>User Registration:</strong> Form submission with validation</li>
            <li>💬 <strong>Message Sender:</strong> Async message sending with error handling</li>
            <li>📎 <strong>File Uploader:</strong> File upload with progress and validation</li>
            <li>🔄 <strong>Built-in States:</strong> Automatic pending, success, and error states</li>
          </ul>
        </div>
      </div>
      <p className="read-the-docs">
        The useAction hook simplifies form handling and async operations with built-in state management
      </p>
    </>
  )
}

export default App
