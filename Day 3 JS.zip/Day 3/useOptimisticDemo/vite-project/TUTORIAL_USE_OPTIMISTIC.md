# useOptimistic Hook Tutorial

## 🎯 Learning Objectives
By the end of this tutorial, you will understand:
- How to use the `useOptimistic` hook for instant UI feedback
- When and why to implement optimistic updates
- Error handling and rollback mechanisms
- Best practices for responsive user interfaces

## 📋 Prerequisites
- Basic knowledge of React hooks (useState, useEffect)
- Understanding of async/await and Promises
- Familiarity with form handling in React
- Basic knowledge of error handling in JavaScript

## 🚀 Getting Started

### Step 1: Navigate to the Project
```bash
cd "c:\Users\Uswer\Desktop\React19Updates\useOptimisticDemo\vite-project"
```

### Step 2: Install Dependencies (if needed)
```bash
npm install
```

### Step 3: Start the Development Server
```bash
npm run dev
```

### Step 4: Open Your Browser
Navigate to the displayed URL (usually `http://localhost:5173`)

### Step 5: Launch the Demo
Click "🚀 Launch useOptimistic Demo" to access the tutorial examples

## 📚 Tutorial Structure

This tutorial contains three practical examples:

### 1. **Message Sending** - Basic Optimistic Updates
### 2. **Post Liking** - Interactive Feedback Systems  
### 3. **Profile Updates** - Form-based Optimistic Changes

---

## 💬 Demo 1: Message Sending

### **What You'll Learn:**
- Basic `useOptimistic` hook usage
- Instant UI feedback during async operations
- Automatic rollback on failures

### **Key Concepts:**
- **Optimistic Update:** UI changes immediately before server confirmation
- **Rollback:** Automatic revert when operations fail
- **Visual States:** Different UI states for pending/sent messages

### **Hook Syntax:**
```javascript
const [optimisticMessages, addOptimisticMessage] = useOptimistic(
  actualMessages,
  (currentMessages, newMessage) => [
    ...currentMessages,
    { ...newMessage, status: 'sending' }
  ]
);
```

### **Hands-On Activities:**

#### Activity 1: Basic Message Sending
1. Type a message in the input field
2. Click "📤 Send"
3. **🔍 Observe:** Message appears instantly with "⏳ Sending..." status
4. **⏱️ Wait:** After 2 seconds, status changes to "✅ Sent"
5. **💡 Key Learning:** UI responds immediately, not after server response

#### Activity 2: Error Handling (10% failure rate)
1. Send multiple messages (try 10-15 messages)
2. **🎯 Eventually:** You'll see a failure (random 10% chance)
3. **🔍 Observe:** Failed message disappears (automatic rollback)
4. **📱 Notice:** Error alert appears
5. **💡 Key Learning:** Failed optimistic updates revert automatically

#### Activity 3: Rapid Message Sending
1. Type and send messages quickly (multiple in succession)
2. **🔍 Watch:** Each message gets its own "sending" state
3. **⚡ Notice:** No UI blocking or race conditions
4. **💡 Key Learning:** `useOptimistic` handles concurrent operations

### **Code Analysis:**
```javascript
const sendMessage = async (messageText) => {
  const optimisticMessage = {
    id: `temp-${Date.now()}`,
    text: messageText,
    timestamp: new Date().toLocaleTimeString()
  };

  startTransition(async () => {
    // 1. Add optimistic message immediately
    addOptimisticMessage(optimisticMessage);
    
    try {
      // 2. Send to server
      const sentMessage = await mockApi.sendMessage(optimisticMessage);
      
      // 3. Update with real message
      setMessages(prev => [...prev, sentMessage]);
    } catch (error) {
      // 4. Optimistic update automatically reverts
      console.error('Failed to send message:', error.message);
    }
  });
};
```

### **Discussion Points:**
- Why use optimistic updates instead of just showing a loading spinner?
- How does the user experience differ with/without optimistic updates?
- What happens if multiple messages are sent rapidly?

---

## ❤️ Demo 2: Post Liking System

### **What You'll Learn:**
- Optimistic updates for interactive elements
- Handling boolean state changes
- Visual feedback for user actions

### **Key Concepts:**
- **Immediate Feedback:** Buttons respond instantly to clicks
- **State Synchronization:** Optimistic and actual state coordination
- **Rollback Behavior:** Failed likes/unlikes revert automatically

### **Hands-On Activities:**

#### Activity 1: Basic Like/Unlike
1. Click the heart buttons on different posts
2. **🔍 Observe:** Hearts fill/empty immediately
3. **📊 Notice:** Like counts update instantly
4. **⏱️ Wait:** 1.5 seconds for server confirmation
5. **💡 Key Learning:** No waiting for server response

#### Activity 2: Rapid Clicking (15% failure rate)
1. Click like buttons rapidly on multiple posts
2. **🎯 Try:** Click the same button multiple times quickly
3. **🔍 Eventually:** See a failure (15% chance per click)
4. **📱 Notice:** Failed likes revert automatically
5. **💡 Key Learning:** Race conditions handled gracefully

#### Activity 3: Visual State Analysis
1. **Before Click:** Empty heart, original count
2. **During Processing:** Filled heart, incremented count  
3. **Success:** State maintained
4. **Failure:** Reverts to original state

### **Code Analysis:**
```javascript
const [optimisticPosts, updateOptimisticPosts] = useOptimistic(
  posts,
  (currentPosts, { postId, liked }) =>
    currentPosts.map(post =>
      post.id === postId
        ? { 
            ...post, 
            likes: liked ? post.likes + 1 : post.likes - 1,
            userLiked: liked 
          }
        : post
    )
);

const toggleLike = (postId, currentlyLiked) => {
  const newLikedState = !currentlyLiked;
  
  startTransition(async () => {
    // Optimistic update
    updateOptimisticPosts({ postId, liked: newLikedState });
    
    try {
      await mockApi.likePost(postId);
      // Update real state
      setPosts(prev => prev.map(post =>
        post.id === postId 
          ? { ...post, likes: newLikedState ? post.likes + 1 : post.likes - 1, userLiked: newLikedState }
          : post
      ));
    } catch (error) {
      // Automatically reverts on failure
      alert('Failed to like post');
    }
  });
};
```

### **Discussion Points:**
- How does optimistic updating improve social media interactions?
- What visual cues help users understand the current state?
- How do you handle conflicting optimistic updates?

---

## 👤 Demo 3: Profile Name Updates

### **What You'll Learn:**
- Form-based optimistic updates
- Input validation with optimistic UI
- User profile management patterns

### **Key Concepts:**
- **Form Integration:** Optimistic updates with form inputs
- **Validation:** Client-side validation before optimistic updates
- **User Feedback:** Visual indicators during processing

### **Hands-On Activities:**

#### Activity 1: Successful Name Update
1. Enter a new name in the input field
2. Click "✏️ Update Name"
3. **🔍 Observe:** Name changes immediately in the profile display
4. **⏳ Notice:** "⏳ Updating..." indicator appears
5. **⏱️ Wait:** 1 second for server confirmation
6. **💡 Key Learning:** Form updates don't block the UI

#### Activity 2: Error Handling (20% failure rate)
1. Try updating the name multiple times
2. **🎯 Eventually:** See a failure (20% chance)
3. **🔍 Observe:** Name reverts to previous value
4. **📱 Notice:** Error alert with failure message
5. **💡 Key Learning:** Form state management handles failures gracefully

#### Activity 3: Rapid Updates
1. Try changing the name multiple times quickly
2. **🔍 Watch:** How the optimistic state handles rapid changes
3. **💡 Key Learning:** Latest optimistic update takes precedence

### **Code Analysis:**
```javascript
const [optimisticProfile, updateOptimisticProfile] = useOptimistic(
  userProfile,
  (currentProfile, newName) => ({
    ...currentProfile,
    name: newName
  })
);

const updateName = (newName) => {
  startTransition(async () => {
    // Optimistic update
    updateOptimisticProfile(newName);
    
    try {
      const result = await mockApi.updateUserName(newName);
      
      // Update real state
      setUserProfile(prev => ({
        ...prev,
        name: result.name,
        lastUpdated: result.updatedAt
      }));
    } catch (error) {
      console.error('Failed to update name:', error.message);
      alert(`Failed to update name: ${error.message}`);
    }
  });
};
```

### **Discussion Points:**
- How do optimistic updates improve form user experience?
- What validation should happen before vs. after optimistic updates?
- How do you handle conflicting form submissions?

---

## 🧠 Deep Dive: useOptimistic Mechanics

### **Hook Parameters:**
```javascript
const [optimisticState, addOptimisticUpdate] = useOptimistic(
  actualState,    // Current "real" state
  updateFunction  // (currentState, action) => newOptimisticState
);
```

### **Update Function Pattern:**
```javascript
const updateFunction = (currentState, action) => {
  // Transform current state based on the action
  return newOptimisticState;
};
```

### **Common Patterns:**

#### 1. Adding Items to Lists
```javascript
const [optimisticItems, addOptimisticItem] = useOptimistic(
  items,
  (currentItems, newItem) => [...currentItems, newItem]
);
```

#### 2. Updating Item Properties
```javascript
const [optimisticItems, updateOptimisticItem] = useOptimistic(
  items,
  (currentItems, { id, updates }) =>
    currentItems.map(item =>
      item.id === id ? { ...item, ...updates } : item
    )
);
```

#### 3. Deleting Items
```javascript
const [optimisticItems, deleteOptimisticItem] = useOptimistic(
  items,
  (currentItems, itemIdToDelete) =>
    currentItems.filter(item => item.id !== itemIdToDelete)
);
```

---

## 🎯 Practical Exercises

### Exercise 1: Shopping Cart Optimistic Updates
Create a shopping cart that:
- Adds items optimistically
- Updates quantities instantly
- Handles server failures gracefully
- Shows loading states appropriately

### Exercise 2: Comment System
Build a comment system with:
- Optimistic comment posting
- Like/unlike functionality
- Reply threading
- Error handling and rollback

### Exercise 3: Real-time Collaboration
Implement a collaborative feature that:
- Shows optimistic edits immediately
- Handles conflicts gracefully
- Provides user feedback
- Syncs with server state

---

## ⚡ Best Practices

### 1. **When to Use Optimistic Updates:**
- ✅ User interactions (likes, follows, simple updates)
- ✅ Form submissions with high success rates
- ✅ Non-critical operations
- ❌ Financial transactions
- ❌ Operations requiring server validation first

### 2. **Error Handling:**
```javascript
try {
  await serverOperation();
  // Update real state
} catch (error) {
  // Provide user feedback
  showErrorMessage(error.message);
  // Optimistic update automatically reverts
}
```

### 3. **Visual Feedback:**
- Use different colors/styles for pending states
- Show loading indicators
- Provide clear success/failure feedback
- Maintain accessibility

### 4. **State Management:**
- Keep optimistic update functions pure
- Use consistent state shapes
- Handle edge cases (rapid clicks, network issues)

---

## 🔧 Troubleshooting

### Common Issues:

1. **Optimistic updates not reverting?**
   - Check that you're not updating actual state in the optimistic function
   - Ensure error handling is properly implemented

2. **Race conditions with rapid updates?**
   - Use `useTransition` to batch updates
   - Implement proper loading states

3. **State synchronization problems?**
   - Verify optimistic state matches actual state structure
   - Check for proper dependency tracking

### Debugging Tips:
- Use console.log to track state changes
- Monitor network requests in DevTools
- Test with slow network conditions
- Verify error handling with forced failures

---

## 📖 Additional Resources

### Documentation:
- [React 19 useOptimistic Hook](https://react.dev/reference/react/useOptimistic)
- [React Transitions](https://react.dev/reference/react/useTransition)
- [Optimistic Updates Pattern](https://react.dev/learn/queueing-a-series-of-state-updates)

### Further Learning:
- Error boundary integration
- Server-state synchronization
- Real-time updates with WebSocket
- Offline-first applications

---

## ✅ Tutorial Completion Checklist

- [ ] Successfully ran all three demos
- [ ] Observed optimistic updates in action
- [ ] Experienced automatic rollback on failures
- [ ] Understood error handling patterns
- [ ] Completed hands-on activities
- [ ] Analyzed code patterns
- [ ] Built own optimistic update component (optional)
- [ ] Tested with various failure scenarios (optional)

---

## 🎉 Congratulations!

You've mastered the `useOptimistic` hook! This powerful React 19 feature enables you to create incredibly responsive user interfaces by showing immediate feedback while handling the complexity of async operations and error states automatically.

**Key Takeaways:**
- Optimistic updates provide instant user feedback
- Automatic rollback handles failures gracefully
- `useOptimistic` simplifies complex state management
- Better UX with minimal code complexity
- Perfect for interactive applications

The `useOptimistic` hook represents a major advancement in creating responsive, user-friendly React applications. Happy building! 🚀