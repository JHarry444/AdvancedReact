# useOptimistic Hook Guide - React 19

## 🚀 What is useOptimistic?

The `useOptimistic` hook is a powerful new React 19 feature that allows you to show optimistic updates in your UI while asynchronous operations are in progress. This creates a much more responsive user experience by immediately showing the expected result, then either confirming or reverting the change based on the actual server response.

## 📖 Basic Syntax

```javascript
import { useOptimistic } from 'react';

const [optimisticState, addOptimisticUpdate] = useOptimistic(
  actualState,
  updateFunction
);
```

### Parameters:
- **`actualState`**: The current actual state
- **`updateFunction`**: A function that takes the current state and an action, returns the optimistically updated state

### Returns:
- **`optimisticState`**: The state to display (either actual or optimistic)
- **`addOptimisticUpdate`**: Function to trigger an optimistic update

## 🎯 Key Benefits

1. **Instant Feedback**: UI updates immediately without waiting for server response
2. **Better UX**: Users see their actions reflected instantly
3. **Automatic Rollback**: Failed operations automatically revert to previous state
4. **Race Condition Safe**: Handles multiple rapid user actions correctly
5. **Loading State Compatible**: Works alongside loading indicators

## 💡 Real-World Examples

### 1. Message Sending

```javascript
const [messages, setMessages] = useState([]);
const [optimisticMessages, addOptimisticMessage] = useOptimistic(
  messages,
  (currentMessages, newMessage) => [
    ...currentMessages,
    { ...newMessage, status: 'sending' }
  ]
);

const sendMessage = async (messageText) => {
  const optimisticMessage = {
    id: `temp-${Date.now()}`,
    text: messageText,
    status: 'sending'
  };

  // Add optimistic update immediately
  addOptimisticMessage(optimisticMessage);
  
  try {
    const sentMessage = await api.sendMessage(messageText);
    setMessages(prev => [...prev, sentMessage]);
  } catch (error) {
    // Optimistic update automatically reverts
    console.error('Failed to send message');
  }
};
```

### 2. Like/Unlike Posts

```javascript
const [posts, setPosts] = useState([...]);
const [optimisticPosts, updateOptimisticPosts] = useOptimistic(
  posts,
  (currentPosts, { postId, liked }) =>
    currentPosts.map(post =>
      post.id === postId
        ? { ...post, likes: liked ? post.likes + 1 : post.likes - 1, userLiked: liked }
        : post
    )
);

const toggleLike = async (postId, currentlyLiked) => {
  const newLikedState = !currentlyLiked;
  
  // Optimistic update
  updateOptimisticPosts({ postId, liked: newLikedState });
  
  try {
    await api.likePost(postId);
    setPosts(prev => prev.map(post =>
      post.id === postId 
        ? { ...post, likes: newLikedState ? post.likes + 1 : post.likes - 1, userLiked: newLikedState }
        : post
    ));
  } catch (error) {
    // Automatically reverts on failure
    alert('Failed to like post');
  }
};
```

## 🔄 How It Works

1. **User Action**: User performs an action (click, submit, etc.)
2. **Optimistic Update**: `addOptimisticUpdate` immediately updates the UI
3. **Server Request**: Actual API call is made in the background
4. **Success**: Real state is updated, optimistic state is replaced
5. **Failure**: Optimistic state automatically reverts to actual state

## ⚡ Best Practices

### 1. Use with useTransition
```javascript
import { useOptimistic, useTransition } from 'react';

const [isPending, startTransition] = useTransition();
const [optimisticData, updateOptimisticData] = useOptimistic(data, updateFn);

const handleAction = (newData) => {
  startTransition(async () => {
    updateOptimisticData(newData);
    try {
      await api.updateData(newData);
      setData(result);
    } catch (error) {
      // Handle error
    }
  });
};
```

### 2. Provide Visual Feedback
```javascript
// Show different states visually
<div style={{
  backgroundColor: item.status === 'sending' ? '#fff3e0' : '#e8f5e8',
  borderLeft: `4px solid ${item.status === 'sending' ? '#ff9800' : '#4caf50'}`
}}>
  {item.text}
  <span>{item.status === 'sending' ? '⏳ Sending...' : '✅ Sent'}</span>
</div>
```

### 3. Handle Errors Gracefully
```javascript
try {
  await api.performAction();
  setActualState(newState);
} catch (error) {
  // Optimistic update automatically reverts
  alert(`Action failed: ${error.message}`);
  // Optionally show error state
}
```

## 🚨 Common Patterns

### Form Submissions
```javascript
const submitForm = async (formData) => {
  addOptimisticUpdate({ ...formData, status: 'submitting' });
  
  try {
    const result = await api.submitForm(formData);
    setFormState(result);
    setInputValue(''); // Clear form
  } catch (error) {
    showErrorMessage(error.message);
  }
};
```

### List Operations
```javascript
const addItem = async (newItem) => {
  const tempItem = { ...newItem, id: `temp-${Date.now()}`, isPending: true };
  addOptimisticItem(tempItem);
  
  try {
    const savedItem = await api.addItem(newItem);
    setItems(prev => [...prev, savedItem]);
  } catch (error) {
    alert('Failed to add item');
  }
};

const deleteItem = async (itemId) => {
  updateOptimisticItems({ type: 'delete', itemId });
  
  try {
    await api.deleteItem(itemId);
    setItems(prev => prev.filter(item => item.id !== itemId));
  } catch (error) {
    alert('Failed to delete item');
  }
};
```

## 🔍 When to Use useOptimistic

### ✅ Good Use Cases:
- Message/chat applications
- Social media interactions (likes, follows, comments)
- Form submissions
- Todo list operations
- Shopping cart updates
- Profile/settings updates

### ❌ Not Recommended For:
- Critical financial transactions
- Operations that must be confirmed server-side first
- Actions with complex validation requirements
- Operations with significant side effects

## 🛠️ Testing Your Implementation

1. **Test the happy path**: Verify optimistic updates work correctly
2. **Test error scenarios**: Ensure rollback works when operations fail
3. **Test rapid interactions**: Verify race conditions are handled
4. **Test network delays**: Use slow network conditions
5. **Test with loading states**: Ensure loading indicators still work

## 📚 Additional Resources

- [React 19 Documentation](https://react.dev)
- [useOptimistic API Reference](https://react.dev/reference/react/useOptimistic)
- [React Transition Hook](https://react.dev/reference/react/useTransition)

---

**The useOptimistic hook represents a major leap forward in creating responsive, user-friendly React applications! 🎉**