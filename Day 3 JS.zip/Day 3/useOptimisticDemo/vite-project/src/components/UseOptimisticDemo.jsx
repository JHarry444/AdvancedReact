import { useState, useOptimistic, useTransition } from 'react';

// Simulated API functions
const simulateDelay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const mockApi = {
  // Simulate sending a message
  sendMessage: async (message) => {
    console.log('🚀 Sending message:', message.text);
    await simulateDelay(2000); // 2 second delay
    
    // Simulate occasional failures
    if (Math.random() < 0.1) {
      throw new Error('Network error - message failed to send');
    }
    
    return {
      ...message,
      id: Date.now(),
      timestamp: new Date().toLocaleTimeString(),
      status: 'sent'
    };
  },

  // Simulate liking a post
  likePost: async (postId) => {
    console.log('👍 Liking post:', postId);
    await simulateDelay(1500);
    
    if (Math.random() < 0.15) {
      throw new Error('Failed to like post');
    }
    
    return { success: true };
  },

  // Simulate updating user name
  updateUserName: async (newName) => {
    console.log('✏️ Updating name to:', newName);
    await simulateDelay(1000);
    
    if (Math.random() < 0.2) {
      throw new Error('Failed to update name');
    }
    
    return { name: newName, updatedAt: new Date().toISOString() };
  }
};

const UseOptimisticDemo = () => {
  return (
    <div style={{ padding: '20px', maxWidth: '1000px', margin: '0 auto' }}>
      <h1>🚀 useOptimistic Hook Demo - React 19</h1>
      
      <div style={{ 
        marginBottom: '20px', 
        padding: '15px', 
        backgroundColor: '#e3f2fd', 
        borderRadius: '8px',
        border: '1px solid #2196f3'
      }}>
        <h2>💡 What is useOptimistic?</h2>
        <p>
          The <code>useOptimistic</code> hook allows you to show optimistic updates in your UI 
          while async operations are in progress. This creates a more responsive user experience 
          by immediately showing expected changes, then either confirming or reverting them based 
          on the actual result.
        </p>
      </div>

      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
        gap: '20px' 
      }}>
        <MessageSender />
        <PostLiker />
        <NameUpdater />
      </div>

      <div style={{ 
        marginTop: '30px', 
        padding: '20px', 
        backgroundColor: '#f5f5f5', 
        borderRadius: '8px' 
      }}>
        <h3>🎯 Key Benefits of useOptimistic:</h3>
        <ul>
          <li>✅ <strong>Instant Feedback:</strong> UI updates immediately</li>
          <li>✅ <strong>Better UX:</strong> No waiting for server responses</li>
          <li>✅ <strong>Error Handling:</strong> Automatically reverts on failure</li>
          <li>✅ <strong>Loading States:</strong> Still shows loading indicators</li>
          <li>✅ <strong>Race Condition Safe:</strong> Handles multiple rapid actions</li>
        </ul>
      </div>
    </div>
  );
};

// Example 1: Optimistic Message Sending
const MessageSender = () => {
  const [messages, setMessages] = useState([
    { id: 1, text: 'Hello! This is an existing message.', status: 'sent', timestamp: '10:30 AM' },
    { id: 2, text: 'Welcome to the useOptimistic demo!', status: 'sent', timestamp: '10:32 AM' }
  ]);
  
  const [optimisticMessages, addOptimisticMessage] = useOptimistic(
    messages,
    (currentMessages, newMessage) => [
      ...currentMessages,
      { ...newMessage, status: 'sending' }
    ]
  );
  
  const [isPending, startTransition] = useTransition();
  const [inputValue, setInputValue] = useState('');

  const sendMessage = async (messageText) => {
    const optimisticMessage = {
      id: `temp-${Date.now()}`,
      text: messageText,
      timestamp: new Date().toLocaleTimeString()
    };

    startTransition(async () => {
      // Add optimistic message immediately
      addOptimisticMessage(optimisticMessage);
      
      try {
        // Send to server
        const sentMessage = await mockApi.sendMessage(optimisticMessage);
        
        // Update with real message
        setMessages(prev => [...prev, sentMessage]);
      } catch (error) {
        console.error('❌ Failed to send message:', error.message);
        alert(`Failed to send message: ${error.message}`);
        // The optimistic update will automatically revert
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inputValue.trim()) {
      sendMessage(inputValue.trim());
      setInputValue('');
    }
  };

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #4caf50', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>💬 Optimistic Message Sending</h3>
      
      <div style={{ 
        height: '200px', 
        overflowY: 'auto', 
        marginBottom: '15px',
        padding: '10px',
        backgroundColor: '#f9f9f9',
        borderRadius: '4px'
      }}>
        {optimisticMessages.map(message => (
          <div 
            key={message.id} 
            style={{
              marginBottom: '10px',
              padding: '8px',
              backgroundColor: message.status === 'sending' ? '#fff3e0' : '#e8f5e8',
              borderRadius: '6px',
              borderLeft: `4px solid ${message.status === 'sending' ? '#ff9800' : '#4caf50'}`
            }}
          >
            <div style={{ fontSize: '14px' }}>{message.text}</div>
            <div style={{ 
              fontSize: '12px', 
              color: '#666', 
              display: 'flex', 
              justifyContent: 'space-between',
              marginTop: '4px'
            }}>
              <span>{message.timestamp}</span>
              <span style={{ 
                color: message.status === 'sending' ? '#ff9800' : '#4caf50',
                fontWeight: 'bold'
              }}>
                {message.status === 'sending' ? '⏳ Sending...' : '✅ Sent'}
              </span>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', gap: '10px' }}>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message..."
            style={{ 
              flex: 1, 
              padding: '8px', 
              borderRadius: '4px', 
              border: '1px solid #ddd' 
            }}
            disabled={isPending}
          />
          <button
            type="submit"
            disabled={isPending || !inputValue.trim()}
            style={{
              padding: '8px 16px',
              backgroundColor: '#4caf50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              opacity: isPending ? 0.6 : 1
            }}
          >
            {isPending ? '⏳' : '📤'} Send
          </button>
        </div>
      </form>
    </div>
  );
};

// Example 2: Optimistic Post Liking
const PostLiker = () => {
  const [posts, setPosts] = useState([
    { id: 1, title: 'React 19 is Amazing!', likes: 42, userLiked: false },
    { id: 2, title: 'useOptimistic Hook Tutorial', likes: 28, userLiked: false },
    { id: 3, title: 'Building Better UX', likes: 67, userLiked: true }
  ]);
  
  const [optimisticPosts, updateOptimisticPosts] = useOptimistic(
    posts,
    (currentPosts, { postId, liked }) =>
      currentPosts.map(post =>
        post.id === postId
          ? { 
              ...post, 
              likes: liked ? post.likes + 1 : post.likes - 1,
              userLiked: liked 
            }
          : post
      )
  );
  
  const [isPending, startTransition] = useTransition();

  const toggleLike = (postId, currentlyLiked) => {
    const newLikedState = !currentlyLiked;
    
    startTransition(async () => {
      // Optimistic update
      updateOptimisticPosts({ postId, liked: newLikedState });
      
      try {
        await mockApi.likePost(postId);
        
        // Update real state
        setPosts(prev => prev.map(post =>
          post.id === postId
            ? { 
                ...post, 
                likes: newLikedState ? post.likes + 1 : post.likes - 1,
                userLiked: newLikedState 
              }
            : post
        ));
      } catch (error) {
        console.error('❌ Failed to like post:', error.message);
        alert(`Failed to ${newLikedState ? 'like' : 'unlike'} post: ${error.message}`);
      }
    });
  };

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #e91e63', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>❤️ Optimistic Post Liking</h3>
      
      <div style={{ display: 'grid', gap: '10px' }}>
        {optimisticPosts.map(post => (
          <div 
            key={post.id}
            style={{
              padding: '15px',
              border: '1px solid #ddd',
              borderRadius: '6px',
              backgroundColor: '#f9f9f9'
            }}
          >
            <h4 style={{ margin: '0 0 10px 0' }}>{post.title}</h4>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <button
                onClick={() => toggleLike(post.id, post.userLiked)}
                disabled={isPending}
                style={{
                  padding: '6px 12px',
                  border: 'none',
                  borderRadius: '4px',
                  backgroundColor: post.userLiked ? '#e91e63' : '#f0f0f0',
                  color: post.userLiked ? 'white' : '#333',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px',
                  opacity: isPending ? 0.6 : 1
                }}
              >
                {post.userLiked ? '❤️' : '🤍'} 
                {post.userLiked ? 'Liked' : 'Like'}
              </button>
              <span style={{ color: '#666' }}>{post.likes} likes</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Example 3: Optimistic Name Updates
const NameUpdater = () => {
  const [userProfile, setUserProfile] = useState({
    name: 'John Doe',
    email: 'john@example.com',
    lastUpdated: '2025-11-12T10:00:00Z'
  });
  
  const [optimisticProfile, updateOptimisticProfile] = useOptimistic(
    userProfile,
    (currentProfile, newName) => ({
      ...currentProfile,
      name: newName
    })
  );
  
  const [isPending, startTransition] = useTransition();
  const [inputValue, setInputValue] = useState('');

  const updateName = (newName) => {
    startTransition(async () => {
      // Optimistic update
      updateOptimisticProfile(newName);
      
      try {
        const result = await mockApi.updateUserName(newName);
        
        // Update real state
        setUserProfile(prev => ({
          ...prev,
          name: result.name,
          lastUpdated: result.updatedAt
        }));
      } catch (error) {
        console.error('❌ Failed to update name:', error.message);
        alert(`Failed to update name: ${error.message}`);
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inputValue.trim() && inputValue.trim() !== userProfile.name) {
      updateName(inputValue.trim());
      setInputValue('');
    }
  };

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid #ff9800', 
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <h3>👤 Optimistic Profile Updates</h3>
      
      <div style={{
        padding: '15px',
        backgroundColor: '#f5f5f5',
        borderRadius: '6px',
        marginBottom: '15px'
      }}>
        <h4 style={{ margin: '0 0 10px 0' }}>Current Profile</h4>
        <div style={{ 
          fontSize: '18px', 
          fontWeight: 'bold',
          color: isPending ? '#ff9800' : '#333'
        }}>
          {optimisticProfile.name}
          {isPending && <span style={{ marginLeft: '10px', fontSize: '14px' }}>⏳ Updating...</span>}
        </div>
        <div style={{ fontSize: '14px', color: '#666', marginTop: '5px' }}>
          {optimisticProfile.email}
        </div>
        <div style={{ fontSize: '12px', color: '#999', marginTop: '5px' }}>
          Last updated: {new Date(userProfile.lastUpdated).toLocaleString()}
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Enter new name..."
            style={{ 
              padding: '8px', 
              borderRadius: '4px', 
              border: '1px solid #ddd' 
            }}
            disabled={isPending}
          />
          <button
            type="submit"
            disabled={isPending || !inputValue.trim() || inputValue.trim() === userProfile.name}
            style={{
              padding: '8px 16px',
              backgroundColor: '#ff9800',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              opacity: isPending ? 0.6 : 1
            }}
          >
            {isPending ? '⏳ Updating...' : '✏️ Update Name'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default UseOptimisticDemo;