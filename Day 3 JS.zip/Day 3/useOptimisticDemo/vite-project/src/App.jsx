import { useState } from 'react'
import UseOptimisticDemo from './components/UseOptimisticDemo'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [showDemo, setShowDemo] = useState(false)

  if (showDemo) {
    return <UseOptimisticDemo />
  }

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>React 19 - useOptimistic Hook</h1>
      <div className="card">
        <button 
          onClick={() => setShowDemo(true)}
          style={{
            padding: '12px 24px',
            fontSize: '16px',
            backgroundColor: '#646cff',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s'
          }}
        >
          🚀 Launch useOptimistic Demo
        </button>
        <p>
          Click the button above to see the <code>useOptimistic</code> hook in action!
        </p>
        <div style={{ 
          marginTop: '20px', 
          padding: '15px', 
          backgroundColor: '#f0f8ff', 
          borderRadius: '8px',
          textAlign: 'left'
        }}>
          <h3>What you'll see:</h3>
          <ul style={{ paddingLeft: '20px' }}>
            <li>💬 <strong>Message Sending:</strong> Instant UI updates while sending</li>
            <li>❤️ <strong>Post Liking:</strong> Immediate like/unlike feedback</li>
            <li>👤 <strong>Profile Updates:</strong> Optimistic name changes</li>
            <li>🔄 <strong>Error Handling:</strong> Automatic rollback on failures</li>
          </ul>
        </div>
      </div>
      <p className="read-the-docs">
        The useOptimistic hook provides instant feedback while async operations are in progress
      </p>
    </>
  )
}

export default App
